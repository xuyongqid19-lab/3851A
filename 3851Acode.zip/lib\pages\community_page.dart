import 'package:flutter/material.dart';
import 'package:geolocator/geolocator.dart';

import '../models/chat_model.dart';
import '../models/user_model.dart';
import '../theme/app_theme.dart';
import '../widgets/chat_widgets.dart';
import 'add_friend_page.dart';
import 'chat_detail_page.dart';
import 'home_page.dart';

final ValueNotifier<List<CommunityActivity>> createdActivityNotifications =
    ValueNotifier<List<CommunityActivity>>([]);
final ValueNotifier<Position?> sharedUserLocation =
    ValueNotifier<Position?>(null);
final ValueNotifier<List<CommunityActivity>> communityActivityDatabase =
    ValueNotifier<List<CommunityActivity>>(_activities);
final ValueNotifier<Map<String, List<String>>> activityAttendees =
    ValueNotifier<Map<String, List<String>>>({});

const _demoLatitude = 39.7817;
const _demoLongitude = -89.6501;
const _nearbyRadiusMeters = 500.0;
const _currentUserName = 'You';

const _nearbyMembers = [
  _NearbyMember(
    name: 'Emma Wilson',
    distance: '0.3 km',
    status: _MemberStatus.friendOnline,
    latitude: _demoLatitude + 0.0018,
    longitude: _demoLongitude + 0.0012,
  ),
  _NearbyMember(
    name: 'Liam Smith',
    distance: '0.6 km',
    status: _MemberStatus.nonFriendOnline,
    latitude: _demoLatitude + 0.0038,
    longitude: _demoLongitude - 0.002,
  ),
  _NearbyMember(
    name: 'Noah Jones',
    distance: '1.2 km',
    status: _MemberStatus.friendOffline,
    latitude: _demoLatitude + 0.0078,
    longitude: _demoLongitude + 0.004,
  ),
  _NearbyMember(
    name: 'Olivia Brown',
    distance: '1.5 km',
    status: _MemberStatus.friendOnline,
    latitude: _demoLatitude - 0.009,
    longitude: _demoLongitude + 0.006,
  ),
  _NearbyMember(
    name: 'Sophia Davis',
    distance: '2.1 km',
    status: _MemberStatus.friendOffline,
    latitude: _demoLatitude - 0.013,
    longitude: _demoLongitude - 0.008,
  ),
];

enum _MemberStatus { friendOnline, friendOffline, nonFriendOnline }

class _NearbyMember {
  const _NearbyMember({
    required this.name,
    required this.distance,
    required this.status,
    required this.latitude,
    required this.longitude,
  });

  final String name;
  final String distance;
  final _MemberStatus status;
  final double latitude;
  final double longitude;

  bool get isFriend => status != _MemberStatus.nonFriendOnline;
  bool get isOnline => status != _MemberStatus.friendOffline;
}

class SelectedLocation {
  const SelectedLocation({
    required this.address,
    required this.latitude,
    required this.longitude,
  });

  final String address;
  final double latitude;
  final double longitude;
}

enum ActivityCategory {
  sports('Sports', Icons.sports_basketball_outlined),
  study('Study', Icons.menu_book_outlined),
  volunteer('Volunteer', Icons.volunteer_activism_outlined),
  family('Family', Icons.family_restroom),
  social('Social', Icons.groups_outlined),
  health('Health', Icons.favorite_border),
  others('Others', Icons.more_horiz);

  const ActivityCategory(this.label, this.icon);
  final String label;
  final IconData icon;
}

class CommunityActivity {
  const CommunityActivity({
    required this.title,
    required this.dateTime,
    required this.location,
    required this.category,
    required this.description,
    required this.latitude,
    required this.longitude,
    required this.groupName,
  });

  final String title;
  final String dateTime;
  final String location;
  final ActivityCategory category;
  final String description;
  final double latitude;
  final double longitude;
  final String groupName;
}

const _activities = [
  CommunityActivity(
    title: 'Basketball Match',
    dateTime: 'Sun, May 25 - 9:00 AM',
    location: 'Riverside Park Basketball Court',
    category: ActivityCategory.sports,
    description:
        'Join us for a friendly match and fun together as a community.',
    latitude: _demoLatitude + 0.001,
    longitude: _demoLongitude + 0.001,
    groupName: 'Basketball Match Group',
  ),
  CommunityActivity(
    title: 'Green Space Picnic',
    dateTime: 'Sun, May 12 - 3:00 PM',
    location: 'Riverside Park - Main Lawn',
    category: ActivityCategory.social,
    description:
        'Bring snacks, blankets, and good energy for a relaxed afternoon together.',
    latitude: _demoLatitude + 0.002,
    longitude: _demoLongitude - 0.001,
    groupName: 'Green Space Picnic Group',
  ),
  CommunityActivity(
    title: 'Morning Yoga in the Park',
    dateTime: 'Sat, May 25 - 7:00 AM',
    location: 'Central Park',
    category: ActivityCategory.health,
    description:
        'Start the morning with a relaxed community walk through the park.',
    latitude: _demoLatitude + 0.0025,
    longitude: _demoLongitude + 0.002,
    groupName: 'Morning Yoga Group',
  ),
  CommunityActivity(
    title: 'Community Clean-Up',
    dateTime: 'Sat, May 31 - 10:00 AM',
    location: 'City Center',
    category: ActivityCategory.volunteer,
    description:
        'Help keep our shared spaces clean. Gloves and bags will be provided.',
    latitude: _demoLatitude + 0.003,
    longitude: _demoLongitude - 0.002,
    groupName: 'Community Clean-Up Group',
  ),
  CommunityActivity(
    title: 'Book Club Meetup',
    dateTime: 'May 15 - 7:00 PM',
    location: 'Community Library',
    category: ActivityCategory.study,
    description:
        'Discuss this month\'s book and vote for the next community read.',
    latitude: _demoLatitude - 0.0025,
    longitude: _demoLongitude + 0.0015,
    groupName: 'Book Club Meetup Group',
  ),
  CommunityActivity(
    title: 'Hiking Adventure',
    dateTime: 'Sun, May 26 - 8:00 AM',
    location: 'Pine Ridge Trail',
    category: ActivityCategory.sports,
    description:
        'Meet early for a scenic hike. Wear comfortable shoes and bring water.',
    latitude: _demoLatitude - 0.003,
    longitude: _demoLongitude - 0.002,
    groupName: 'Hiking Adventure Group',
  ),
];

class CommunityPage extends StatelessWidget {
  const CommunityPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        _CommunityHeader(
          onNotifications: () => Navigator.of(context).push(
            MaterialPageRoute<void>(builder: (_) => const NotificationsPage()),
          ),
        ),
        Expanded(
          child: _CommunityHomeContent(),
        ),
      ],
    );
  }
}

class ActivityListPage extends StatelessWidget {
  const ActivityListPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [
            const _SimpleHeader(showBack: true),
            Expanded(
              child: ValueListenableBuilder<List<CommunityActivity>>(
                valueListenable: communityActivityDatabase,
                builder: (context, activities, _) {
                  final visibleActivities = activities
                      .where((a) => a.title != 'Basketball Match')
                      .toList();
                  return ListView.separated(
                    padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
                    itemCount: visibleActivities.length,
                    separatorBuilder: (_, __) => const SizedBox(height: 12),
                    itemBuilder: (context, index) {
                      final activity = visibleActivities[index];
                      return _ActivityCard(
                        activity: activity,
                        onTap: () => Navigator.of(context).push(
                          MaterialPageRoute<void>(
                            builder: (_) =>
                                ActivityDetailPage(activity: activity),
                          ),
                        ),
                      );
                    },
                  );
                },
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNav(
                  selectedIndex: 1,
                  onSelected: (i) => Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(builder: (_) => HomePage(initialTabIndex: i)),
                    (route) => false,
                  ),
                ),
    );
  }
}

class _CommunityHomeContent extends StatefulWidget {
  @override
  State<_CommunityHomeContent> createState() => _CommunityHomeContentState();
}

class _CommunityHomeContentState extends State<_CommunityHomeContent> {
  final _searchController = TextEditingController();
  Position? _position;
  String _query = '';

  @override
  void initState() {
    super.initState();
    _shareCurrentLocation();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _shareCurrentLocation() async {
    final position = await _getCurrentPositionOrNull();
    if (!mounted || position == null) return;
    setState(() => _position = position);
    sharedUserLocation.value = position;
  }

  @override
  Widget build(BuildContext context) {
    final q = _query.toLowerCase();
    final members = _nearbyMembersWithin(_position)
        .where((member) => q.isEmpty || member.name.toLowerCase().contains(q))
        .toList();
    return ListView(
      padding: const EdgeInsets.fromLTRB(18, 12, 18, 22),
      children: [
        _CommunitySearchField(
          controller: _searchController,
          onChanged: (value) => setState(() => _query = value.trim()),
        ),
        const SizedBox(height: 16),
        _CommunityGroupCard(
          onTap: () => Navigator.of(context).push(
            MaterialPageRoute<void>(
              builder: (_) => const NearbyFriendsMapPage(),
            ),
          ),
        ),
        const SizedBox(height: 18),
        const _SectionHeader(title: 'Nearby Members for You'),
        const SizedBox(height: 8),
        for (final member in members) _SuggestedPersonTile(member: member),
        const Divider(height: 24, color: Color(0xFFE1E1E1)),
        _SectionHeader(
          title: 'Nearby Activities',
          actionLabel: 'View all',
          onAction: () => Navigator.of(context).push(
            MaterialPageRoute<void>(builder: (_) => const ActivityListPage()),
          ),
        ),
        const SizedBox(height: 8),
        ValueListenableBuilder<List<CommunityActivity>>(
          valueListenable: communityActivityDatabase,
          builder: (context, activities, _) {
            final nearbyActivities =
                _nearbyActivitiesWithin(_position, activities)
                    .where((activity) =>
                        q.isEmpty ||
                        activity.title.toLowerCase().contains(q) ||
                        activity.location.toLowerCase().contains(q))
                    .toList();
            return Column(
              children: [
                if (nearbyActivities.isEmpty)
                  const Padding(
                    padding: EdgeInsets.symmetric(vertical: 14),
                    child: Text(
                      'No nearby activities found.',
                      style: TextStyle(color: AppTheme.muted),
                    ),
                  )
                else
                  for (final activity in nearbyActivities.take(3))
                    _CompactActivityTile(
                      activity: activity,
                      onTap: () => Navigator.of(context).push(
                        MaterialPageRoute<void>(
                          builder: (_) =>
                              ActivityDetailPage(activity: activity),
                        ),
                      ),
                    ),
              ],
            );
          },
        ),
        Padding(
          padding: const EdgeInsets.only(top: 4, bottom: 6),
          child: Text(
            _position == null
                ? 'Allow location to show people and activities within 500 m.'
                : 'Your location is shared. Showing matches within 500 m.',
            style: const TextStyle(fontSize: 11, color: AppTheme.muted),
          ),
        ),
        const SizedBox(height: 8),
        OutlinedButton.icon(
          onPressed: () => Navigator.of(context).push(
            MaterialPageRoute<void>(builder: (_) => const CreateActivityPage()),
          ),
          style: OutlinedButton.styleFrom(
            foregroundColor: AppTheme.ink,
            side: const BorderSide(color: Color(0xFFBDBDBD)),
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(7)),
          ),
          icon: const Icon(Icons.add, size: 18),
          label: const Text(
            'Create Activity',
            style: TextStyle(fontWeight: FontWeight.w800),
          ),
        ),
      ],
    );
  }
}

class _CommunitySearchField extends StatelessWidget {
  const _CommunitySearchField({
    this.controller,
    this.onChanged,
  });

  final TextEditingController? controller;
  final ValueChanged<String>? onChanged;

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      onChanged: onChanged,
      decoration: InputDecoration(
        hintText: 'Search people or activities',
        prefixIcon: const Icon(Icons.search, size: 21),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(7)),
        enabledBorder: OutlineInputBorder(
          borderRadius: BorderRadius.circular(7),
          borderSide: const BorderSide(color: Color(0xFFD1D1D1)),
        ),
      ),
    );
  }
}

class _CommunityGroupCard extends StatelessWidget {
  const _CommunityGroupCard({required this.onTap});

  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(7),
      child: Container(
        padding: const EdgeInsets.fromLTRB(14, 12, 10, 12),
        decoration: BoxDecoration(
          border: Border.all(color: const Color(0xFFE0E0E0)),
          borderRadius: BorderRadius.circular(7),
        ),
        child: const Row(
          children: [
            _CircleIcon(icon: Icons.location_on_outlined, size: 42),
            SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Find Community Friends',
                    style: TextStyle(fontWeight: FontWeight.w800),
                  ),
                  SizedBox(height: 3),
                  Text(
                    'Match nearby people by distance',
                    style: TextStyle(fontSize: 12),
                  ),
                ],
              ),
            ),
            Icon(Icons.chevron_right, size: 28),
          ],
        ),
      ),
    );
  }
}

class _SectionHeader extends StatelessWidget {
  const _SectionHeader({
    required this.title,
    this.actionLabel,
    this.onAction,
  });

  final String title;
  final String? actionLabel;
  final VoidCallback? onAction;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Text(
          title,
          style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
        ),
        const Spacer(),
        if (actionLabel != null && onAction != null)
          TextButton(
            onPressed: onAction,
            style: TextButton.styleFrom(
              foregroundColor: AppTheme.ink,
              padding: EdgeInsets.zero,
              minimumSize: const Size(54, 32),
            ),
            child: Text(
              actionLabel!,
              style: const TextStyle(fontSize: 12),
            ),
          ),
      ],
    );
  }
}

class _SuggestedPersonTile extends StatelessWidget {
  const _SuggestedPersonTile({required this.member});

  final _NearbyMember member;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 48,
      child: Row(
        children: [
          Stack(
            children: [
              const _CircleIcon(icon: Icons.person_outline, size: 38),
              Positioned(
                right: 0,
                bottom: 2,
                child: Container(
                  width: 9,
                  height: 9,
                  decoration: BoxDecoration(
                    color: _statusColor(member.status),
                    shape: BoxShape.circle,
                    border: Border.all(color: Colors.white, width: 1.5),
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(member.name,
                    style: const TextStyle(fontWeight: FontWeight.w700)),
                const SizedBox(height: 2),
                Text(
                  '${member.distance} - ${member.isOnline ? 'Online' : 'Offline'}',
                  style: const TextStyle(fontSize: 13),
                ),
              ],
            ),
          ),
          SizedBox(
            width: 60,
            height: 36,
            child: OutlinedButton(
              onPressed: () {
                if (member.isFriend) {
                  _openChat(context, member.name);
                } else {
                  _openAddFriend(context, member.name);
                }
              },
              style: OutlinedButton.styleFrom(
                foregroundColor: AppTheme.ink,
                side: const BorderSide(color: Color(0xFFBDBDBD)),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(7),
                ),
                padding: EdgeInsets.zero,
              ),
              child: Text(
                member.isFriend ? 'Chat' : 'Add',
                style: const TextStyle(fontWeight: FontWeight.w800),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _CompactActivityTile extends StatelessWidget {
  const _CompactActivityTile({required this.activity, required this.onTap});

  final CommunityActivity activity;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: SizedBox(
        height: 58,
        child: Row(
          children: [
            _CircleIcon(icon: activity.category.icon, size: 42),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    activity.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 4),
                  Text(activity.dateTime, style: const TextStyle(fontSize: 13)),
                ],
              ),
            ),
            SizedBox(
              width: 60,
              height: 36,
              child: OutlinedButton(
                onPressed: onTap,
                style: OutlinedButton.styleFrom(
                  foregroundColor: AppTheme.ink,
                  side: const BorderSide(color: Color(0xFFBDBDBD)),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(7),
                  ),
                  padding: EdgeInsets.zero,
                ),
                child: const Text(
                  'Join',
                  style: TextStyle(fontWeight: FontWeight.w800),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class NearbyFriendsMapPage extends StatefulWidget {
  const NearbyFriendsMapPage({super.key});

  @override
  State<NearbyFriendsMapPage> createState() => _NearbyFriendsMapPageState();
}

class _NearbyFriendsMapPageState extends State<NearbyFriendsMapPage> {
  final _searchController = TextEditingController();
  Position? _position;
  String? _locationError;
  bool _locating = true;
  String _query = '';

  @override
  void initState() {
    super.initState();
    _locateUser();
  }

  @override
  void dispose() {
    _searchController.dispose();
    super.dispose();
  }

  Future<void> _locateUser() async {
    setState(() {
      _locating = true;
      _locationError = null;
    });

    try {
      final serviceEnabled = await Geolocator.isLocationServiceEnabled();
      if (!serviceEnabled) {
        setState(() {
          _locationError = 'Location services are disabled.';
          _locating = false;
        });
        return;
      }

      var permission = await Geolocator.checkPermission();
      if (permission == LocationPermission.denied) {
        permission = await Geolocator.requestPermission();
      }
      if (permission == LocationPermission.denied ||
          permission == LocationPermission.deniedForever) {
        setState(() {
          _locationError = 'Location permission was not granted.';
          _locating = false;
        });
        return;
      }

      final position = await Geolocator.getCurrentPosition(
        locationSettings: const LocationSettings(
          accuracy: LocationAccuracy.high,
        ),
      );
      if (!mounted) return;
      setState(() {
        _position = position;
        _locating = false;
      });
      sharedUserLocation.value = position;
    } catch (_) {
      if (!mounted) return;
      setState(() {
        _locationError = 'Unable to get current location.';
        _locating = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final q = _query.toLowerCase();
    final members = _nearbyMembersWithin(_position)
        .where((member) => q.isEmpty || member.name.toLowerCase().contains(q))
        .toList();
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [
            const _SimpleHeader(showBack: true),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 10),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _searchController,
                      onChanged: (value) =>
                          setState(() => _query = value.trim()),
                      decoration: InputDecoration(
                        hintText: 'Search nearby friends',
                        prefixIcon: const Icon(Icons.search),
                        contentPadding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 12),
                        border: OutlineInputBorder(
                            borderRadius: BorderRadius.circular(8)),
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Expanded(
              child: _NearbyMapCanvas(
                position: _position,
                locating: _locating,
                error: _locationError,
                onLocate: _locateUser,
                members: members,
              ),
            ),
            const _MapLegend(),
            Container(
              padding: const EdgeInsets.fromLTRB(20, 14, 20, 18),
              decoration: const BoxDecoration(
                color: Colors.white,
                border: Border(top: BorderSide(color: Color(0xFFE6E6E6))),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text(
                    'Nearby Community Friends',
                    style: TextStyle(fontSize: 16, fontWeight: FontWeight.w800),
                  ),
                  const SizedBox(height: 12),
                  if (members.isEmpty)
                    const Text(
                      'No nearby people found.',
                      style: TextStyle(color: AppTheme.muted),
                    )
                  else
                    for (final member in members)
                      _NearbyFriendTile(member: member),
                ],
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNav(
                  selectedIndex: 1,
                  onSelected: (i) => Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(builder: (_) => HomePage(initialTabIndex: i)),
                    (route) => false,
                  ),
                ),
    );
  }
}

class ActivityDetailPage extends StatelessWidget {
  const ActivityDetailPage({required this.activity, super.key});

  final CommunityActivity activity;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [
            const _SimpleHeader(showBack: true),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(26, 26, 26, 26),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        _CircleIcon(icon: activity.category.icon, size: 74),
                        const SizedBox(width: 20),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                activity.title,
                                style: const TextStyle(
                                  fontSize: 20,
                                  fontWeight: FontWeight.w800,
                                  color: AppTheme.ink,
                                ),
                              ),
                              const SizedBox(height: 9),
                              _IconText(
                                  icon: Icons.calendar_today_outlined,
                                  text: activity.dateTime),
                              const SizedBox(height: 8),
                              _IconText(
                                  icon: Icons.location_on_outlined,
                                  text: activity.location),
                            ],
                          ),
                        ),
                      ],
                    ),
                    const SizedBox(height: 26),
                    const Divider(color: Color(0xFFDADADA)),
                    const SizedBox(height: 24),
                    const _SectionTitle('About'),
                    const SizedBox(height: 10),
                    Text(activity.description,
                        style: const TextStyle(fontSize: 14, height: 1.5)),
                    const SizedBox(height: 30),
                    ValueListenableBuilder<Map<String, List<String>>>(
                      valueListenable: activityAttendees,
                      builder: (context, attendeesByActivity, _) {
                        final attendees = attendeesByActivity[activity.title] ??
                            const <String>[];
                        return Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Row(
                              children: [
                                Text(
                                  'Who\'s Going (${attendees.length})',
                                  style: const TextStyle(
                                    fontSize: 16,
                                    fontWeight: FontWeight.w800,
                                    color: AppTheme.ink,
                                  ),
                                ),
                                const Spacer(),
                                TextButton(
                                  onPressed: attendees.isEmpty
                                      ? null
                                      : () => _showAttendees(
                                            context,
                                            activity,
                                            attendees,
                                          ),
                                  style: TextButton.styleFrom(
                                      foregroundColor: AppTheme.ink),
                                  child: const Text('View all'),
                                ),
                              ],
                            ),
                            const SizedBox(height: 10),
                            if (attendees.isEmpty)
                              const Text(
                                'No one has joined yet.',
                                style: TextStyle(color: AppTheme.muted),
                              )
                            else
                              Wrap(
                                spacing: 10,
                                runSpacing: 10,
                                children: [
                                  for (final attendee in attendees.take(5))
                                    InkWell(
                                      customBorder: const CircleBorder(),
                                      onTap: () => Navigator.of(context).push(
                                        MaterialPageRoute<void>(
                                          builder: (_) => UserProfilePage(
                                            memberName: attendee,
                                          ),
                                        ),
                                      ),
                                      child: const _CircleIcon(
                                          icon: Icons.person_outline, size: 42),
                                    ),
                                  if (attendees.length > 5)
                                    Container(
                                      width: 42,
                                      height: 42,
                                      alignment: Alignment.center,
                                      decoration: BoxDecoration(
                                        shape: BoxShape.circle,
                                        border:
                                            Border.all(color: AppTheme.muted),
                                      ),
                                      child: Text(
                                        '+${attendees.length - 5}',
                                        style: const TextStyle(
                                            fontWeight: FontWeight.w700),
                                      ),
                                    ),
                                ],
                              ),
                          ],
                        );
                      },
                    ),
                    const SizedBox(height: 30),
                    const _SectionTitle('What to Bring'),
                    const SizedBox(height: 10),
                    const Text(
                        'Bring water, comfortable clothes, and good vibes!'),
                    const SizedBox(height: 28),
                    const _SectionTitle('Activity Group'),
                    const SizedBox(height: 10),
                    OutlinedButton.icon(
                      onPressed: () => _openActivityGroup(context, activity),
                      style: OutlinedButton.styleFrom(
                        foregroundColor: AppTheme.ink,
                        side: const BorderSide(color: Color(0xFFBDBDBD)),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(7),
                        ),
                        minimumSize: const Size(double.infinity, 46),
                      ),
                      icon: const Icon(Icons.group_add_outlined),
                      label: Text(
                        'Add Group: ${activity.groupName}',
                        style: const TextStyle(fontWeight: FontWeight.w800),
                      ),
                    ),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(26, 10, 26, 20),
              child: _PrimaryBlackButton(
                  label: 'Join Activity',
                  onPressed: () {
                    _joinActivity(activity);
                    _showSnack(context, 'Joined activity and entered group');
                    _openActivityGroup(context, activity);
                  }),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNav(
                  selectedIndex: 1,
                  onSelected: (i) => Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(builder: (_) => HomePage(initialTabIndex: i)),
                    (route) => false,
                  ),
                ),
    );
  }
}

class CreateActivityPage extends StatefulWidget {
  const CreateActivityPage({super.key});

  @override
  State<CreateActivityPage> createState() => _CreateActivityPageState();
}

class _CreateActivityPageState extends State<CreateActivityPage> {
  final _titleController = TextEditingController();
  final _addressController = TextEditingController();
  final _descriptionController = TextEditingController();
  ActivityCategory? _category;
  bool _showCategories = false;
  DateTime? _selectedDate;
  TimeOfDay? _selectedTime;
  SelectedLocation? _selectedLocation;

  @override
  void initState() {
    super.initState();
    _prefillCurrentLocation();
  }

  @override
  void dispose() {
    _titleController.dispose();
    _addressController.dispose();
    _descriptionController.dispose();
    super.dispose();
  }

  Future<void> _selectLocation() async {
    final location = await Navigator.of(context).push<SelectedLocation>(
      MaterialPageRoute<SelectedLocation>(
        builder: (_) => const SelectLocationPage(),
      ),
    );
    if (location != null && mounted) {
      setState(() {
        _selectedLocation = location;
        _addressController.text = location.address;
      });
    }
  }

  Future<void> _prefillCurrentLocation() async {
    final position = await _getCurrentPositionOrNull();
    if (!mounted || position == null) return;
    setState(() {
      _selectedLocation = SelectedLocation(
        address: 'Current Location',
        latitude: position.latitude,
        longitude: position.longitude,
      );
      _addressController.text = 'Current Location';
    });
  }

  Future<void> _selectDate() async {
    final date = await showDatePicker(
      context: context,
      initialDate: _selectedDate ?? DateTime(2026, 5, 25),
      firstDate: DateTime(2024),
      lastDate: DateTime(2030),
    );
    if (date != null && mounted) {
      setState(() => _selectedDate = date);
    }
  }

  Future<void> _selectTime() async {
    final time = await showTimePicker(
      context: context,
      initialTime: _selectedTime ?? const TimeOfDay(hour: 9, minute: 0),
    );
    if (time != null && mounted) {
      setState(() => _selectedTime = time);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [
            const _SimpleHeader(showBack: true),
            Expanded(
              child: SingleChildScrollView(
                padding: const EdgeInsets.fromLTRB(22, 18, 22, 20),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const _FormLabel('Activity Title'),
                    _TextInput(
                        controller: _titleController,
                        hint: 'Enter activity title'),
                    const SizedBox(height: 16),
                    const _FormLabel('Category'),
                    _CategoryField(
                      selected: _category,
                      expanded: _showCategories,
                      onTap: () =>
                          setState(() => _showCategories = !_showCategories),
                      onSelected: (category) => setState(() {
                        _category = category;
                        _showCategories = false;
                      }),
                    ),
                    const SizedBox(height: 16),
                    const Row(
                      children: [
                        Expanded(child: _FormLabel('Date')),
                        SizedBox(width: 18),
                        Expanded(child: _FormLabel('Time')),
                      ],
                    ),
                    Row(
                      children: [
                        Expanded(
                            child: _FakePicker(
                                hint: _selectedDate == null
                                    ? 'Select date'
                                    : _formatDate(_selectedDate!),
                                icon: Icons.calendar_today_outlined,
                                onTap: _selectDate)),
                        const SizedBox(width: 18),
                        Expanded(
                            child: _FakePicker(
                                hint: _selectedTime == null
                                    ? 'Select time'
                                    : _selectedTime!.format(context),
                                icon: Icons.access_time,
                                onTap: _selectTime)),
                      ],
                    ),
                    const SizedBox(height: 16),
                    const _FormLabel('Address'),
                    GestureDetector(
                      onTap: _selectLocation,
                      child: AbsorbPointer(
                        child: _TextInput(
                            controller: _addressController,
                            hint: 'Search address'),
                      ),
                    ),
                    const SizedBox(height: 10),
                    GestureDetector(
                        onTap: _selectLocation,
                        child: const _MapPreview(height: 112)),
                    const SizedBox(height: 16),
                    const _FormLabel('Description'),
                    _TextInput(
                      controller: _descriptionController,
                      hint: 'Tell others about your activity...',
                      maxLines: 3,
                    ),
                  ],
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(22, 8, 22, 18),
              child: _PrimaryBlackButton(
                  label: 'Create Activity',
                  onPressed: () {
                    final title = _titleController.text.trim().isEmpty
                        ? 'New Community Activity'
                        : _titleController.text.trim();
                    final activity = CommunityActivity(
                      title: title,
                      dateTime:
                          '${_selectedDate == null ? 'Selected date' : _formatDate(_selectedDate!)} - ${_selectedTime?.format(context) ?? 'Selected time'}',
                      location: _addressController.text.trim().isEmpty
                          ? 'Selected location'
                          : _addressController.text.trim(),
                      category: _category ?? ActivityCategory.social,
                      description: _descriptionController.text.trim().isEmpty
                          ? 'A new community activity has been created.'
                          : _descriptionController.text.trim(),
                      latitude: _selectedLocation?.latitude ??
                          sharedUserLocation.value?.latitude ??
                          _demoLatitude,
                      longitude: _selectedLocation?.longitude ??
                          sharedUserLocation.value?.longitude ??
                          _demoLongitude,
                      groupName: '$title Group',
                    );
                    communityActivityDatabase.value = [
                      activity,
                      ...communityActivityDatabase.value,
                    ];
                    createdActivityNotifications.value = [
                      activity,
                      ...createdActivityNotifications.value,
                    ];
                    _showSnack(context, 'Activity created');
                  }),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNav(
                  selectedIndex: 1,
                  onSelected: (i) => Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(builder: (_) => HomePage(initialTabIndex: i)),
                    (route) => false,
                  ),
                ),
    );
  }
}

class SelectLocationPage extends StatefulWidget {
  const SelectLocationPage({super.key});

  @override
  State<SelectLocationPage> createState() => _SelectLocationPageState();
}

class _SelectLocationPageState extends State<SelectLocationPage> {
  final _addressSearchController = TextEditingController();
  SelectedLocation _location = const SelectedLocation(
    address: 'Riverside Park Basketball Court',
    latitude: _demoLatitude,
    longitude: _demoLongitude,
  );
  bool _locating = true;

  @override
  void initState() {
    super.initState();
    _locate();
  }

  @override
  void dispose() {
    _addressSearchController.dispose();
    super.dispose();
  }

  Future<void> _locate() async {
    setState(() => _locating = true);
    final position = await _getCurrentPositionOrNull();
    if (!mounted) return;
    if (position != null) {
      setState(() {
        _location = SelectedLocation(
          address: 'Current Location',
          latitude: position.latitude,
          longitude: position.longitude,
        );
        _locating = false;
      });
    } else {
      setState(() => _locating = false);
    }
  }

  void _useTypedAddress(String value) {
    final address = value.trim();
    if (address.isEmpty) return;
    setState(() {
      _location = SelectedLocation(
        address: address,
        latitude: _location.latitude,
        longitude: _location.longitude,
      );
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [
            const _SimpleHeader(),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 12),
              child: _SearchLocationField(
                controller: _addressSearchController,
                onSubmitted: _useTypedAddress,
              ),
            ),
            Expanded(
              child: _MapPreview(
                height: double.infinity,
                large: true,
                onLocate: _locate,
                label: _locating
                    ? 'Locating...'
                    : '${_location.latitude.toStringAsFixed(4)}, ${_location.longitude.toStringAsFixed(4)}',
              ),
            ),
            Container(
              margin: const EdgeInsets.fromLTRB(20, 10, 20, 12),
              padding: const EdgeInsets.all(18),
              decoration: BoxDecoration(
                border: Border.all(color: const Color(0xFFD6D6D6)),
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Icon(Icons.location_on_outlined, size: 24),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        const Text('Selected Address',
                            style: TextStyle(
                                fontSize: 16, fontWeight: FontWeight.w800)),
                        const SizedBox(height: 18),
                        Text(_location.address,
                            style:
                                const TextStyle(fontWeight: FontWeight.w700)),
                        const SizedBox(height: 4),
                        Text(
                          '${_location.latitude.toStringAsFixed(5)}, ${_location.longitude.toStringAsFixed(5)}',
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 0, 20, 18),
              child: _PrimaryBlackButton(
                label: 'Confirm Location',
                onPressed: () => Navigator.of(context).pop(_location),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNav(
                  selectedIndex: 1,
                  onSelected: (i) => Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(builder: (_) => HomePage(initialTabIndex: i)),
                    (route) => false,
                  ),
                ),
    );
  }
}

class NotificationsPage extends StatelessWidget {
  const NotificationsPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: const SafeArea(
        child: Column(
          children: [
            _SimpleHeader(leadingIcon: Icons.notifications_none),
            Expanded(child: _NotificationsList()),
          ],
        ),
      ),
      bottomNavigationBar: BottomNav(
                  selectedIndex: 1,
                  onSelected: (i) => Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(builder: (_) => HomePage(initialTabIndex: i)),
                    (route) => false,
                  ),
                ),
    );
  }
}

class _CommunityHeader extends StatelessWidget {
  const _CommunityHeader({required this.onNotifications});

  final VoidCallback onNotifications;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.only(top: MediaQuery.of(context).padding.top),
      color: Colors.white,
      child: SizedBox(
        height: 58,
        child: Stack(
          alignment: Alignment.center,
          children: [
            Positioned(
              left: 8,
              top: 5,
              child: IconButton(
                tooltip: 'Notifications',
                onPressed: onNotifications,
                icon: const Icon(Icons.notifications_none, size: 24),
              ),
            ),
            const Text(
              'Global Village',
              textAlign: TextAlign.center,
              style: TextStyle(
                  fontSize: 18,
                  fontWeight: FontWeight.w700,
                  color: AppTheme.ink),
            ),
          ],
        ),
      ),
    );
  }
}

class _ActivityCard extends StatelessWidget {
  const _ActivityCard({required this.activity, required this.onTap});

  final CommunityActivity activity;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      borderRadius: BorderRadius.circular(8),
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          border: Border.all(color: const Color(0xFFE0E0E0)),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Row(
          children: [
            _CircleIcon(icon: activity.category.icon, size: 58),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    activity.title,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(
                        fontSize: 15,
                        fontWeight: FontWeight.w700,
                        color: AppTheme.ink),
                  ),
                  const SizedBox(height: 5),
                  Text(activity.dateTime, style: const TextStyle(fontSize: 13)),
                  const SizedBox(height: 5),
                  Text(
                    activity.location,
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 13),
                  ),
                ],
              ),
            ),
            const SizedBox(width: 10),
            OutlinedButton(
              onPressed: onTap,
              style: OutlinedButton.styleFrom(
                foregroundColor: AppTheme.ink,
                side: const BorderSide(color: Color(0xFFBDBDBD)),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(7)),
                minimumSize: const Size(58, 42),
                padding: EdgeInsets.zero,
              ),
              child: const Text('Join',
                  style: TextStyle(fontWeight: FontWeight.w700)),
            ),
          ],
        ),
      ),
    );
  }
}

class _NearbyMapCanvas extends StatelessWidget {
  const _NearbyMapCanvas({
    required this.position,
    required this.locating,
    required this.error,
    required this.onLocate,
    required this.members,
  });

  final Position? position;
  final bool locating;
  final String? error;
  final VoidCallback onLocate;
  final List<_NearbyMember> members;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      color: const Color(0xFFF0F0F0),
      child: CustomPaint(
        painter: _MapPainter(),
        child: Stack(
          children: [
            for (final entry in members.asMap().entries)
              _PositionedMapPin(
                index: entry.key,
                member: entry.value,
              ),
            Center(
              child: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Container(
                    width: 15,
                    height: 15,
                    decoration: BoxDecoration(
                      color: Colors.blue,
                      shape: BoxShape.circle,
                      border: Border.all(color: Colors.white, width: 2),
                      boxShadow: const [
                        BoxShadow(
                          color: Color(0x33000000),
                          blurRadius: 8,
                          offset: Offset(0, 2),
                        )
                      ],
                    ),
                  ),
                  const SizedBox(height: 8),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                    decoration: BoxDecoration(
                      color: Colors.white,
                      border: Border.all(color: const Color(0xFFD6D6D6)),
                      borderRadius: BorderRadius.circular(14),
                    ),
                    child: Text(
                      locating
                          ? 'Locating...'
                          : error ??
                              'You: ${position!.latitude.toStringAsFixed(4)}, ${position!.longitude.toStringAsFixed(4)}',
                      style: const TextStyle(
                        fontSize: 11,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ),
                ],
              ),
            ),
            Positioned(
              right: 20,
              bottom: 20,
              child: InkWell(
                onTap: onLocate,
                customBorder: const CircleBorder(),
                child: Container(
                  width: 44,
                  height: 44,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.circle,
                    border: Border.all(color: AppTheme.border),
                  ),
                  child: const Icon(Icons.gps_fixed, size: 22),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MapFriendPin extends StatelessWidget {
  const _MapFriendPin({required this.member});

  final _NearbyMember member;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      customBorder: const CircleBorder(),
      onTap: () {
        if (member.isFriend) {
          _openChat(context, member.name);
        } else {
          _openAddFriend(context, member.name);
        }
      },
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          const _CircleIcon(icon: Icons.person_outline, size: 36),
          Positioned(
            right: -1,
            bottom: 1,
            child: Container(
              width: 9,
              height: 9,
              decoration: BoxDecoration(
                color: _statusColor(member.status),
                shape: BoxShape.circle,
                border: Border.all(color: Colors.white, width: 1.4),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _PositionedMapPin extends StatelessWidget {
  const _PositionedMapPin({
    required this.index,
    required this.member,
  });

  final int index;
  final _NearbyMember member;

  @override
  Widget build(BuildContext context) {
    final positions = [
      const (left: 32.0, top: 54.0, right: null, bottom: null),
      const (left: 98.0, top: 102.0, right: null, bottom: null),
      const (left: null, top: 64.0, right: 32.0, bottom: null),
      const (left: 52.0, top: null, right: null, bottom: 74.0),
      const (left: null, top: null, right: 92.0, bottom: 54.0),
      const (left: null, top: null, right: 24.0, bottom: 118.0),
    ];
    final p = positions[index % positions.length];
    return Positioned(
      left: p.left,
      top: p.top,
      right: p.right,
      bottom: p.bottom,
      child: _MapFriendPin(member: member),
    );
  }
}

class _MapLegend extends StatelessWidget {
  const _MapLegend();

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.fromLTRB(18, 8, 18, 8),
      decoration: const BoxDecoration(
        color: Colors.white,
        border: Border(top: BorderSide(color: Color(0xFFE6E6E6))),
      ),
      child: const Row(
        children: [
          _LegendItem(color: Colors.green, label: 'Friend Online'),
          SizedBox(width: 10),
          _LegendItem(color: Colors.red, label: 'Friend Offline'),
          SizedBox(width: 10),
          _LegendItem(color: Colors.blue, label: 'Non-friend Online'),
        ],
      ),
    );
  }
}

class _LegendItem extends StatelessWidget {
  const _LegendItem({required this.color, required this.label});

  final Color color;
  final String label;

  @override
  Widget build(BuildContext context) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          width: 8,
          height: 8,
          decoration: BoxDecoration(color: color, shape: BoxShape.circle),
        ),
        const SizedBox(width: 4),
        Text(label, style: const TextStyle(fontSize: 11)),
      ],
    );
  }
}

class _NearbyFriendTile extends StatelessWidget {
  const _NearbyFriendTile({required this.member});

  final _NearbyMember member;

  @override
  Widget build(BuildContext context) {
    return ListTile(
      contentPadding: EdgeInsets.zero,
      leading: Stack(
        children: [
          const _CircleIcon(icon: Icons.person_outline, size: 42),
          Positioned(
            right: 0,
            bottom: 2,
            child: Container(
              width: 9,
              height: 9,
              decoration: BoxDecoration(
                color: _statusColor(member.status),
                shape: BoxShape.circle,
                border: Border.all(color: Colors.white, width: 1.5),
              ),
            ),
          ),
        ],
      ),
      title: Text(member.name,
          style: const TextStyle(fontWeight: FontWeight.w700)),
      subtitle: Text(
        '${member.distance} - ${member.isOnline ? 'Online' : 'Offline'}',
      ),
      trailing: OutlinedButton(
        onPressed: () {
          if (member.isFriend) {
            _openChat(context, member.name);
          } else {
            _openAddFriend(context, member.name);
          }
        },
        style: OutlinedButton.styleFrom(
          foregroundColor: AppTheme.ink,
          side: const BorderSide(color: Color(0xFFBDBDBD)),
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(7)),
        ),
        child: Text(member.isFriend ? 'Chat' : 'Add'),
      ),
    );
  }
}

class _SimpleHeader extends StatelessWidget {
  const _SimpleHeader({this.showBack = false, this.leadingIcon});

  final bool showBack;
  final IconData? leadingIcon;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      height: 62,
      child: Stack(
        alignment: Alignment.center,
        children: [
          Positioned(
            left: 8,
            top: 7,
            child: IconButton(
              tooltip: showBack ? 'Back' : 'Notifications',
              onPressed: showBack ? () => Navigator.maybePop(context) : null,
              icon: Icon(showBack ? Icons.arrow_back_ios_new : leadingIcon,
                  size: 22),
            ),
          ),
          const Text(
            'Global Village',
            style: TextStyle(
                fontSize: 18, fontWeight: FontWeight.w800, color: AppTheme.ink),
          ),
        ],
      ),
    );
  }
}

class _CircleIcon extends StatelessWidget {
  const _CircleIcon({required this.icon, required this.size});

  final IconData icon;
  final double size;

  @override
  Widget build(BuildContext context) {
    return Container(
      width: size,
      height: size,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(color: AppTheme.ink, width: 1.3),
      ),
      child: Icon(icon, size: size * 0.52, color: AppTheme.ink),
    );
  }
}

class _IconText extends StatelessWidget {
  const _IconText({required this.icon, required this.text});

  final IconData icon;
  final String text;

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        Icon(icon, size: 17),
        const SizedBox(width: 8),
        Expanded(child: Text(text, style: const TextStyle(fontSize: 13))),
      ],
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle(this.text);

  final String text;

  @override
  Widget build(BuildContext context) {
    return Text(text,
        style: const TextStyle(
            fontSize: 16, fontWeight: FontWeight.w800, color: AppTheme.ink));
  }
}

class _FormLabel extends StatelessWidget {
  const _FormLabel(this.text);

  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 7),
      child: Text(text,
          style: const TextStyle(
              fontSize: 15, fontWeight: FontWeight.w800, color: AppTheme.ink)),
    );
  }
}

class _TextInput extends StatelessWidget {
  const _TextInput(
      {required this.controller, required this.hint, this.maxLines = 1});

  final TextEditingController controller;
  final String hint;
  final int maxLines;

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      maxLines: maxLines,
      decoration: InputDecoration(
        hintText: hint,
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
      ),
    );
  }
}

class _CategoryField extends StatelessWidget {
  const _CategoryField({
    required this.selected,
    required this.expanded,
    required this.onTap,
    required this.onSelected,
  });

  final ActivityCategory? selected;
  final bool expanded;
  final VoidCallback onTap;
  final ValueChanged<ActivityCategory> onSelected;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        InkWell(
          onTap: onTap,
          child: Container(
            height: 48,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            decoration: BoxDecoration(
              border:
                  Border.all(color: expanded ? AppTheme.ink : AppTheme.border),
              borderRadius: BorderRadius.circular(7),
            ),
            child: Row(
              children: [
                Expanded(
                  child: Text(
                    selected?.label ?? 'Select category',
                    style: TextStyle(
                        color: selected == null
                            ? const Color(0xFF9A9A9A)
                            : AppTheme.ink),
                  ),
                ),
                Icon(expanded
                    ? Icons.keyboard_arrow_up
                    : Icons.keyboard_arrow_down),
              ],
            ),
          ),
        ),
        if (expanded)
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 6),
            decoration: BoxDecoration(
              color: Colors.white,
              border: Border.all(color: AppTheme.ink),
              borderRadius:
                  const BorderRadius.vertical(bottom: Radius.circular(7)),
              boxShadow: const [
                BoxShadow(
                    color: Color(0x22000000),
                    blurRadius: 8,
                    offset: Offset(0, 4))
              ],
            ),
            child: Column(
              children: ActivityCategory.values.map((category) {
                final active = selected == category;
                return ListTile(
                  dense: true,
                  visualDensity: VisualDensity.compact,
                  leading: Icon(category.icon, color: AppTheme.ink),
                  title: Text(category.label,
                      style: const TextStyle(fontWeight: FontWeight.w700)),
                  trailing: active
                      ? const Icon(Icons.check, color: AppTheme.ink)
                      : null,
                  onTap: () => onSelected(category),
                );
              }).toList(),
            ),
          ),
      ],
    );
  }
}

class _FakePicker extends StatelessWidget {
  const _FakePicker({
    required this.hint,
    required this.icon,
    required this.onTap,
  });

  final String hint;
  final IconData icon;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(7),
      child: Container(
        height: 48,
        padding: const EdgeInsets.symmetric(horizontal: 12),
        decoration: BoxDecoration(
          border: Border.all(color: AppTheme.border),
          borderRadius: BorderRadius.circular(7),
        ),
        child: Row(
          children: [
            Expanded(
              child: Text(
                hint,
                style: TextStyle(
                  color: hint.startsWith('Select')
                      ? const Color(0xFF9A9A9A)
                      : AppTheme.ink,
                  fontSize: 13,
                ),
              ),
            ),
            Icon(icon, size: 19),
          ],
        ),
      ),
    );
  }
}

class _MapPreview extends StatelessWidget {
  const _MapPreview({
    required this.height,
    this.large = false,
    this.onLocate,
    this.label,
  });

  final double height;
  final bool large;
  final VoidCallback? onLocate;
  final String? label;

  @override
  Widget build(BuildContext context) {
    return Container(
      height: height,
      width: double.infinity,
      clipBehavior: Clip.antiAlias,
      decoration: BoxDecoration(
        color: const Color(0xFFF0F0F0),
        borderRadius: BorderRadius.circular(8),
        border: Border.all(color: const Color(0xFFE0E0E0)),
      ),
      child: CustomPaint(
        painter: _MapPainter(),
        child: Stack(
          children: [
            Center(
                child: Icon(Icons.location_on,
                    size: large ? 54 : 42, color: AppTheme.ink)),
            if (label != null)
              Positioned(
                left: 16,
                bottom: 16,
                child: Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
                  decoration: BoxDecoration(
                    color: Colors.white,
                    border: Border.all(color: const Color(0xFFD6D6D6)),
                    borderRadius: BorderRadius.circular(14),
                  ),
                  child: Text(
                    label!,
                    style: const TextStyle(
                      fontSize: 12,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ),
              ),
            Positioned(
              right: 14,
              bottom: 14,
              child: InkWell(
                onTap: onLocate,
                customBorder: const CircleBorder(),
                child: Container(
                  width: 42,
                  height: 42,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    shape: BoxShape.circle,
                    border: Border.all(color: AppTheme.border),
                  ),
                  child: const Icon(Icons.my_location, size: 22),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MapPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final roadPaint = Paint()
      ..color = Colors.white
      ..strokeWidth = 4;
    final thinRoadPaint = Paint()
      ..color = const Color(0xBFFFFFFF)
      ..strokeWidth = 2;

    for (var x = -size.height; x < size.width + size.height; x += 48) {
      canvas.drawLine(
          Offset(x, 0), Offset(x + size.height, size.height), roadPaint);
    }
    for (var x = 0.0; x < size.width; x += 36) {
      canvas.drawLine(Offset(x, 0), Offset(x - 50, size.height), thinRoadPaint);
    }
    for (var y = 18.0; y < size.height; y += 34) {
      canvas.drawLine(Offset(0, y), Offset(size.width, y + 20), thinRoadPaint);
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

class _PrimaryBlackButton extends StatelessWidget {
  const _PrimaryBlackButton({required this.label, required this.onPressed});

  final String label;
  final VoidCallback onPressed;

  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 50,
      child: FilledButton(
        onPressed: onPressed,
        style: FilledButton.styleFrom(
          backgroundColor: AppTheme.ink,
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
        ),
        child: Text(label, style: const TextStyle(fontWeight: FontWeight.w800)),
      ),
    );
  }
}

class _SearchLocationField extends StatelessWidget {
  const _SearchLocationField({
    required this.controller,
    required this.onSubmitted,
  });

  final TextEditingController controller;
  final ValueChanged<String> onSubmitted;

  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: controller,
      textInputAction: TextInputAction.done,
      onSubmitted: onSubmitted,
      decoration: InputDecoration(
        hintText: 'Search address',
        prefixIcon: const Icon(Icons.search),
        contentPadding:
            const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(8)),
      ),
    );
  }
}

class _NotificationsList extends StatelessWidget {
  const _NotificationsList();

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<List<CommunityActivity>>(
      valueListenable: createdActivityNotifications,
      builder: (context, createdActivities, _) {
        return ListView(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 20),
          children: [
            const _NotificationSection('Upcoming Activities'),
            for (final activity in createdActivities)
              _NotificationTile(
                icon: activity.category.icon,
                title: activity.title,
                subtitle: '${activity.dateTime}\n${activity.location}',
                time: 'Just now',
                onTap: () => _openActivityDetail(context, activity),
              ),
            _NotificationTile(
              icon: Icons.sports_basketball_outlined,
              title: 'Basketball Match',
              subtitle:
                  'Sun, May 25 - 9:00 AM\nRiverside Park Basketball Court',
              time: 'In 1 day',
              onTap: () => _openActivityDetail(context, _activities[0]),
            ),
            _NotificationTile(
              icon: Icons.self_improvement_outlined,
              title: 'Morning Yoga',
              subtitle: 'Sun, May 25 - 7:00 AM\nGreenfield Park',
              time: 'In 1 day',
              onTap: () => _openActivityDetail(context, _activities[2]),
            ),
            const _NotificationSection('Activity Updates'),
            _NotificationTile(
              icon: Icons.menu_book_outlined,
              title: 'Book Club Meeting',
              subtitle: 'Location changed to Community Library.',
              time: 'Yesterday',
              onTap: () => _openActivityDetail(context, _activities[4]),
            ),
            const _NotificationSection('Health Check-in Reminders'),
            _NotificationTile(
              icon: Icons.water_drop_outlined,
              title: 'Water Intake',
              subtitle: 'Don\'t forget to drink water!',
              time: '8:15 AM',
              onTap: () => _openPlaceholder(context, 'Health Check-In'),
            ),
            _NotificationTile(
              icon: Icons.directions_walk,
              title: 'Walk Goal',
              subtitle: 'You haven\'t logged your walk today.',
              time: '9:00 AM',
              onTap: () => _openPlaceholder(context, 'Walk Goal'),
            ),
            const _NotificationSection('Messages'),
            _NotificationTile(
              icon: Icons.mark_unread_chat_alt_outlined,
              title: 'New Message',
              subtitle: 'Emma: See you at the meetup!',
              time: '7:45 AM',
              onTap: () => _openChat(context, 'Emma Wilson'),
            ),
          ],
        );
      },
    );
  }
}

class _NotificationSection extends StatelessWidget {
  const _NotificationSection(this.title);

  final String title;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(top: 12, bottom: 10),
      child: Text(title,
          style: const TextStyle(
              fontSize: 16, fontWeight: FontWeight.w800, color: AppTheme.ink)),
    );
  }
}

class _NotificationTile extends StatelessWidget {
  const _NotificationTile({
    required this.icon,
    required this.title,
    required this.subtitle,
    required this.time,
    required this.onTap,
  });

  final IconData icon;
  final String title;
  final String subtitle;
  final String time;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 12),
        decoration: const BoxDecoration(
            border: Border(bottom: BorderSide(color: Color(0xFFE6E6E6)))),
        child: Row(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            _CircleIcon(icon: icon, size: 48),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(title,
                      style: const TextStyle(fontWeight: FontWeight.w800)),
                  const SizedBox(height: 4),
                  Text(subtitle,
                      style: const TextStyle(fontSize: 12, height: 1.35)),
                ],
              ),
            ),
            const SizedBox(width: 8),
            Column(
              crossAxisAlignment: CrossAxisAlignment.end,
              children: [
                Text(time, style: const TextStyle(fontSize: 12)),
                const SizedBox(height: 18),
                Container(
                  width: 8,
                  height: 8,
                  decoration: const BoxDecoration(
                      color: Colors.blue, shape: BoxShape.circle),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class UserProfilePage extends StatelessWidget {
  const UserProfilePage({required this.memberName, super.key});

  final String memberName;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [
            const _SimpleHeader(showBack: true),
            Expanded(
              child: Padding(
                padding: const EdgeInsets.all(28),
                child: Column(
                  children: [
                    const SizedBox(height: 28),
                    const _CircleIcon(icon: Icons.person_outline, size: 92),
                    const SizedBox(height: 20),
                    Text(
                      memberName,
                      style: const TextStyle(
                        fontSize: 24,
                        fontWeight: FontWeight.w800,
                      ),
                    ),
                    const SizedBox(height: 8),
                    const Text(
                      'Community Member',
                      style: TextStyle(color: AppTheme.muted),
                    ),
                    const SizedBox(height: 28),
                    _PrimaryBlackButton(
                      label: 'Message',
                      onPressed: () => _openChat(context, memberName),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNav(
                  selectedIndex: 1,
                  onSelected: (i) => Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(builder: (_) => HomePage(initialTabIndex: i)),
                    (route) => false,
                  ),
                ),
    );
  }
}

class PlaceholderFeaturePage extends StatelessWidget {
  const PlaceholderFeaturePage({required this.title, super.key});

  final String title;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [
            const _SimpleHeader(showBack: true),
            Expanded(
              child: Center(
                child: Padding(
                  padding: const EdgeInsets.all(28),
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const _CircleIcon(
                          icon: Icons.construction_outlined, size: 76),
                      const SizedBox(height: 18),
                      Text(
                        title,
                        style: const TextStyle(
                          fontSize: 24,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                      const SizedBox(height: 10),
                      const Text(
                        'This feature is reserved for the health module.',
                        textAlign: TextAlign.center,
                        style: TextStyle(color: AppTheme.muted),
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNav(
                  selectedIndex: 1,
                  onSelected: (i) => Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(builder: (_) => HomePage(initialTabIndex: i)),
                    (route) => false,
                  ),
                ),
    );
  }
}

Color _statusColor(_MemberStatus status) {
  return switch (status) {
    _MemberStatus.friendOnline => Colors.green,
    _MemberStatus.friendOffline => Colors.red,
    _MemberStatus.nonFriendOnline => Colors.blue,
  };
}

Future<Position?> _getCurrentPositionOrNull() async {
  try {
    final serviceEnabled = await Geolocator.isLocationServiceEnabled();
    if (!serviceEnabled) return null;

    var permission = await Geolocator.checkPermission();
    if (permission == LocationPermission.denied) {
      permission = await Geolocator.requestPermission();
    }
    if (permission == LocationPermission.denied ||
        permission == LocationPermission.deniedForever) {
      return null;
    }

    return Geolocator.getCurrentPosition(
      locationSettings: const LocationSettings(
        accuracy: LocationAccuracy.high,
      ),
    );
  } catch (_) {
    return null;
  }
}

List<_NearbyMember> _nearbyMembersWithin(Position? position) {
  if (position == null) return _nearbyMembers;
  final nearby = _nearbyMembers.where((member) {
    final meters = Geolocator.distanceBetween(
      position.latitude,
      position.longitude,
      member.latitude,
      member.longitude,
    );
    return meters <= _nearbyRadiusMeters;
  }).toList();
  return nearby.isEmpty ? _nearbyMembers.take(2).toList() : nearby;
}

List<CommunityActivity> _nearbyActivitiesWithin(
  Position? position,
  List<CommunityActivity> activities,
) {
  if (position == null) return [_activities[2], _activities[3], _activities[0]];
  final nearby = activities.where((activity) {
    final meters = Geolocator.distanceBetween(
      position.latitude,
      position.longitude,
      activity.latitude,
      activity.longitude,
    );
    return meters <= _nearbyRadiusMeters;
  }).toList();
  return nearby.isEmpty ? activities.take(3).toList() : nearby;
}

AppUser _userForName(String name) {
  final username = '@${name.toLowerCase().replaceAll(' ', '')}';
  return allUsers.firstWhere(
    (user) => user.name == name,
    orElse: () => AppUser(
      name: name,
      username: username,
      mutualFriends: 2,
      sharedInterests: const ['Community Events', 'Wellness'],
      sameGroups: const ['Global Village'],
    ),
  );
}

void _openAddFriend(BuildContext context, String name) {
  Navigator.of(context).push(
    MaterialPageRoute<bool>(
      builder: (_) => AddFriendPage(user: _userForName(name)),
    ),
  );
}

void _openChat(BuildContext context, String name) {
  Navigator.of(context).push(
    MaterialPageRoute<void>(
      builder: (_) => ChatDetailPage(
        chat: Chat(
          name: name,
          time: 'Now',
          unreadCount: 0,
          preview: 'Community chat',
        ),
      ),
    ),
  );
}

void _openActivityGroup(BuildContext context, CommunityActivity activity) {
  _joinActivity(activity);
  Navigator.of(context).push(
    MaterialPageRoute<void>(
      builder: (_) => ChatDetailPage(
        chat: Chat(
          name: activity.groupName,
          time: 'Now',
          unreadCount: 0,
          preview: 'All joined members are added automatically.',
          isGroup: true,
          category: 'Groups',
        ),
      ),
    ),
  );
}

void _openActivityDetail(BuildContext context, CommunityActivity activity) {
  Navigator.of(context).push(
    MaterialPageRoute<void>(
      builder: (_) => ActivityDetailPage(activity: activity),
    ),
  );
}

void _openPlaceholder(BuildContext context, String title) {
  Navigator.of(context).push(
    MaterialPageRoute<void>(
      builder: (_) => PlaceholderFeaturePage(title: title),
    ),
  );
}

void _showSnack(BuildContext context, String message) {
  ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
}

void _joinActivity(CommunityActivity activity) {
  final current = Map<String, List<String>>.from(activityAttendees.value);
  final attendees = List<String>.from(current[activity.title] ?? const []);
  if (!attendees.contains(_currentUserName)) {
    attendees.add(_currentUserName);
  }
  current[activity.title] = attendees;
  activityAttendees.value = current;
}

String _formatDate(DateTime date) {
  const months = [
    'Jan',
    'Feb',
    'Mar',
    'Apr',
    'May',
    'Jun',
    'Jul',
    'Aug',
    'Sep',
    'Oct',
    'Nov',
    'Dec'
  ];
  return '${months[date.month - 1]} ${date.day}, ${date.year}';
}

void _showAttendees(
  BuildContext context,
  CommunityActivity activity,
  List<String> attendees,
) {
  showModalBottomSheet<void>(
    context: context,
    backgroundColor: Colors.white,
    showDragHandle: true,
    builder: (context) {
      return ListView(
        padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
        shrinkWrap: true,
        children: [
          Text(
            '${activity.title} Attendees (${attendees.length})',
            style: const TextStyle(fontSize: 18, fontWeight: FontWeight.w800),
          ),
          const SizedBox(height: 12),
          for (final name in attendees)
            ListTile(
              contentPadding: EdgeInsets.zero,
              leading: const _CircleIcon(icon: Icons.person_outline, size: 42),
              title: Text(name),
              subtitle: const Text('Going'),
              onTap: () {
                Navigator.of(context).pop();
                Navigator.of(context).push(
                  MaterialPageRoute<void>(
                    builder: (_) => UserProfilePage(memberName: name),
                  ),
                );
              },
            ),
        ],
      );
    },
  );
}
