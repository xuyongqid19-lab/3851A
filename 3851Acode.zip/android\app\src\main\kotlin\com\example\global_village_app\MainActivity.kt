package com.example.global_village_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
