import 'package:flutter/material.dart';

import '../models/profile_model.dart';
import '../theme/app_theme.dart';

class ProfilePage extends StatefulWidget {
  const ProfilePage({super.key});

  @override
  State<ProfilePage> createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage>
    with SingleTickerProviderStateMixin {
  late TabController _tabController;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(length: 3, vsync: this);
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
              color: Colors.white,
              child: const Row(
                children: [
                  Text(
                    'Profile',
                    style: TextStyle(
                      fontSize: 26,
                      fontWeight: FontWeight.w700,
                      color: AppTheme.ink,
                    ),
                  ),
                ],
              ),
            ),
            TabBar(
              controller: _tabController,
              labelColor: AppTheme.ink,
              unselectedLabelColor: const Color(0xFF9A9A9A),
              indicatorColor: AppTheme.ink,
              indicatorWeight: 2,
              tabs: const [
                Tab(text: 'My Profile'),
                Tab(text: 'Interest Match'),
                Tab(text: 'Recommended'),
              ],
            ),
            Expanded(
              child: TabBarView(
                controller: _tabController,
                children: const [
                  _MyProfileTab(),
                  _InterestMatchTab(),
                  _RecommendedMatchTab(),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _MyProfileTab extends StatefulWidget {
  const _MyProfileTab();

  @override
  State<_MyProfileTab> createState() => _MyProfileTabState();
}

class _MyProfileTabState extends State<_MyProfileTab> {
  bool _editing = false;
  late TextEditingController _nameCtrl;
  late TextEditingController _usernameCtrl;
  late TextEditingController _ageCtrl;
  late TextEditingController _emailCtrl;
  late TextEditingController _phoneCtrl;
  late TextEditingController _addressCtrl;
  late List<String> _selectedInterests;
  late String _selectedCommunity;

  @override
  void initState() {
    super.initState();
    _initControllers(currentProfile.value);
  }

  void _initControllers(ProfileData p) {
    _nameCtrl = TextEditingController(text: p.name);
    _usernameCtrl = TextEditingController(text: p.username);
    _ageCtrl = TextEditingController(text: p.age.toString());
    _emailCtrl = TextEditingController(text: p.email);
    _phoneCtrl = TextEditingController(text: p.phone);
    _addressCtrl = TextEditingController(text: p.address);
    _selectedInterests = List.from(p.interestTags);
    _selectedCommunity = p.community;
  }

  @override
  void dispose() {
    _nameCtrl.dispose();
    _usernameCtrl.dispose();
    _ageCtrl.dispose();
    _emailCtrl.dispose();
    _phoneCtrl.dispose();
    _addressCtrl.dispose();
    super.dispose();
  }

  void _save() {
    final age = int.tryParse(_ageCtrl.text) ?? 0;
    currentProfile.value = ProfileData(
      name: _nameCtrl.text,
      username: _usernameCtrl.text,
      age: age,
      email: _emailCtrl.text,
      phone: _phoneCtrl.text,
      community: _selectedCommunity,
      address: _addressCtrl.text,
      interestTags: _selectedInterests,
    );
    setState(() => _editing = false);
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Profile updated successfully')),
    );
  }

  void _cancel() {
    _initControllers(currentProfile.value);
    setState(() => _editing = false);
  }

  @override
  Widget build(BuildContext context) {
    final p = currentProfile.value;
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(20, 16, 20, 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              CircleAvatar(
                radius: 36,
                backgroundColor: AppTheme.ink,
                child: Text(
                  p.name.isNotEmpty ? p.name[0].toUpperCase() : '?',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 28,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ),
              const SizedBox(width: 16),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(p.name,
                        style: const TextStyle(
                            fontSize: 20, fontWeight: FontWeight.w700)),
                    const SizedBox(height: 4),
                    Text(p.username,
                        style: const TextStyle(
                            color: AppTheme.muted, fontSize: 14)),
                  ],
                ),
              ),
              if (!_editing)
                TextButton.icon(
                  onPressed: () => setState(() => _editing = true),
                  icon: const Icon(Icons.edit_outlined, size: 18),
                  label: const Text('Edit'),
                  style: TextButton.styleFrom(foregroundColor: AppTheme.ink),
                ),
            ],
          ),
          const SizedBox(height: 24),
          if (_editing) ...[
            _buildSectionTitle('Personal Information'),
            const SizedBox(height: 12),
            _buildEditableField('Name', _nameCtrl),
            const SizedBox(height: 12),
            _buildEditableField('Username', _usernameCtrl),
            const SizedBox(height: 12),
            _buildEditableField('Age', _ageCtrl,
                keyboardType: TextInputType.number),
            const SizedBox(height: 12),
            _buildEditableField('Email', _emailCtrl,
                keyboardType: TextInputType.emailAddress),
            const SizedBox(height: 12),
            _buildEditableField('Phone', _phoneCtrl,
                keyboardType: TextInputType.phone),
            const SizedBox(height: 12),
            _buildEditableField('Address', _addressCtrl),
            const SizedBox(height: 18),
            _buildSectionTitle('Community'),
            const SizedBox(height: 8),
            _buildCommunityDropdown(),
            const SizedBox(height: 18),
            _buildSectionTitle('Interest Tags'),
            const SizedBox(height: 8),
            _buildInterestChips(editable: true),
            const SizedBox(height: 24),
            Row(
              children: [
                Expanded(
                  child: _buildButton('Cancel', outlined: true, onTap: _cancel),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: _buildButton('Save', onTap: _save),
                ),
              ],
            ),
          ] else ...[
            _buildSectionTitle('Personal Information'),
            const SizedBox(height: 8),
            _buildInfoRow(Icons.person_outline, 'Name', p.name),
            _buildInfoRow(Icons.badge_outlined, 'Username', p.username),
            _buildInfoRow(Icons.numbers_outlined, 'Age', '${p.age}'),
            _buildInfoRow(Icons.email_outlined, 'Email', p.email),
            _buildInfoRow(Icons.phone_outlined, 'Phone', p.phone),
            _buildInfoRow(Icons.home_outlined, 'Address', p.address),
            const SizedBox(height: 16),
            _buildSectionTitle('Community'),
            const SizedBox(height: 8),
            _buildInfoRow(Icons.groups_outlined, 'Community', p.community),
            const SizedBox(height: 16),
            _buildSectionTitle('Interest Tags'),
            const SizedBox(height: 8),
            _buildInterestChips(editable: false),
          ],
        ],
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Text(title,
        style: const TextStyle(
            fontSize: 16, fontWeight: FontWeight.w700, color: AppTheme.ink));
  }

  Widget _buildInfoRow(IconData icon, String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        children: [
          Icon(icon, size: 20, color: AppTheme.muted),
          const SizedBox(width: 10),
          SizedBox(
              width: 80,
              child: Text(label,
                  style: const TextStyle(
                      color: AppTheme.muted, fontWeight: FontWeight.w500))),
          Expanded(
              child: Text(value,
                  style: const TextStyle(fontWeight: FontWeight.w600))),
        ],
      ),
    );
  }

  Widget _buildEditableField(String label, TextEditingController ctrl,
      {TextInputType? keyboardType}) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(label,
            style: const TextStyle(
                fontSize: 13,
                fontWeight: FontWeight.w600,
                color: AppTheme.muted)),
        const SizedBox(height: 4),
        TextFormField(
          controller: ctrl,
          keyboardType: keyboardType,
          decoration: InputDecoration(
            isDense: true,
            contentPadding:
                const EdgeInsets.symmetric(horizontal: 12, vertical: 12),
            border: OutlineInputBorder(
                borderRadius: BorderRadius.circular(6),
                borderSide: const BorderSide(color: AppTheme.border)),
            enabledBorder: OutlineInputBorder(
                borderRadius: BorderRadius.circular(6),
                borderSide: const BorderSide(color: AppTheme.border)),
          ),
        ),
      ],
    );
  }

  Widget _buildCommunityDropdown() {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12),
      decoration: BoxDecoration(
        border: Border.all(color: AppTheme.border),
        borderRadius: BorderRadius.circular(6),
      ),
      child: DropdownButtonHideUnderline(
        child: DropdownButton<String>(
          value: _selectedCommunity.isEmpty ? null : _selectedCommunity,
          isExpanded: true,
          hint: const Text('Select community',
              style: TextStyle(color: Color(0xFF9A9A9A))),
          items: availableCommunities
              .map((c) =>
                  DropdownMenuItem(value: c, child: Text(c)))
              .toList(),
          onChanged: (v) {
            if (v != null) setState(() => _selectedCommunity = v);
          },
        ),
      ),
    );
  }

  Widget _buildInterestChips({required bool editable}) {
    return Wrap(
      spacing: 8,
      runSpacing: 8,
      children: availableInterests.map((interest) {
        final selected = _selectedInterests.contains(interest);
        return FilterChip(
          label: Text(interest, style: const TextStyle(fontSize: 13)),
          selected: selected,
          onSelected: editable
              ? (val) {
                  setState(() {
                    if (val) {
                      _selectedInterests.add(interest);
                    } else {
                      _selectedInterests.remove(interest);
                    }
                  });
                }
              : null,
          selectedColor: AppTheme.ink.withOpacity(0.15),
          checkmarkColor: AppTheme.ink,
          side: BorderSide(
            color: selected ? AppTheme.ink : AppTheme.border,
          ),
        );
      }).toList(),
    );
  }

  Widget _buildButton(String label,
      {bool outlined = false, required VoidCallback onTap}) {
    if (outlined) {
      return SizedBox(
        height: 44,
        child: OutlinedButton(
          onPressed: onTap,
          style: OutlinedButton.styleFrom(
            foregroundColor: AppTheme.ink,
            side: const BorderSide(color: AppTheme.ink),
            shape:
                RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
          ),
          child: Text(label,
              style: const TextStyle(fontWeight: FontWeight.w700)),
        ),
      );
    }
    return SizedBox(
      height: 44,
      child: FilledButton(
        onPressed: onTap,
        style: FilledButton.styleFrom(
          backgroundColor: AppTheme.ink,
          foregroundColor: Colors.white,
          shape:
              RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
        ),
        child:
            Text(label, style: const TextStyle(fontWeight: FontWeight.w700)),
      ),
    );
  }
}

class _InterestMatchTab extends StatelessWidget {
  const _InterestMatchTab();

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<ProfileData>(
      valueListenable: currentProfile,
      builder: (context, profile, _) {
        final matches = interestMatch(profile);
        return _MatchList(
          matches: matches,
          emptyMessage: 'Add interest tags to get match suggestions.',
          title: 'Based on your interests and age',
        );
      },
    );
  }
}

class _RecommendedMatchTab extends StatelessWidget {
  const _RecommendedMatchTab();

  @override
  Widget build(BuildContext context) {
    return ValueListenableBuilder<ProfileData>(
      valueListenable: currentProfile,
      builder: (context, profile, _) {
        final matches = recommendMatch(profile);
        return _MatchList(
          matches: matches,
          emptyMessage: 'Update your profile to get recommendations.',
          title: 'Based on community, age & interests',
        );
      },
    );
  }
}

class _MatchList extends StatelessWidget {
  final List<MatchUser> matches;
  final String emptyMessage;
  final String title;

  const _MatchList({
    required this.matches,
    required this.emptyMessage,
    required this.title,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 12, 20, 4),
          child: Text(title,
              style: const TextStyle(
                  fontSize: 13, color: AppTheme.muted)),
        ),
        Expanded(
          child: matches.isEmpty
              ? Center(
                  child: Padding(
                    padding: const EdgeInsets.all(32),
                    child: Text(emptyMessage,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                            color: AppTheme.muted, fontSize: 15)),
                  ),
                )
              : ListView.separated(
                  padding: const EdgeInsets.fromLTRB(20, 8, 20, 20),
                  itemCount: matches.length,
                  separatorBuilder: (_, __) =>
                      const Divider(height: 1, color: Color(0xFFF0F0F0)),
                  itemBuilder: (_, i) => _MatchTile(user: matches[i]),
                ),
        ),
      ],
    );
  }
}

class _MatchTile extends StatelessWidget {
  final MatchUser user;

  const _MatchTile({required this.user});

  @override
  Widget build(BuildContext context) {
    final scoreColor = user.matchScore >= 70
        ? Colors.green
        : user.matchScore >= 40
            ? Colors.orange
            : Colors.grey;
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 10),
      child: Row(
        children: [
          CircleAvatar(
            radius: 26,
            backgroundColor: AppTheme.ink.withOpacity(0.1),
            child: Text(
              user.avatarInitial,
              style: const TextStyle(
                fontSize: 20,
                fontWeight: FontWeight.w700,
                color: AppTheme.ink,
              ),
            ),
          ),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(user.name,
                    style: const TextStyle(
                        fontWeight: FontWeight.w700, fontSize: 15)),
                const SizedBox(height: 4),
                Row(
                  children: [
                    Text('${user.age} yrs',
                        style: const TextStyle(fontSize: 12)),
                    if (user.community.isNotEmpty) ...[
                      const SizedBox(width: 8),
                      Icon(Icons.location_on_outlined,
                          size: 12, color: AppTheme.muted),
                      const SizedBox(width: 2),
                      Expanded(
                        child: Text(user.community,
                            style: const TextStyle(
                                fontSize: 12, color: AppTheme.muted),
                            overflow: TextOverflow.ellipsis),
                      ),
                    ],
                  ],
                ),
                if (user.interestTags.isNotEmpty) ...[
                  const SizedBox(height: 4),
                  SizedBox(
                    height: 24,
                    child: ListView.separated(
                      scrollDirection: Axis.horizontal,
                      itemCount: user.interestTags.length,
                      separatorBuilder: (_, __) => const SizedBox(width: 4),
                      itemBuilder: (_, i) => Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 8, vertical: 3),
                        decoration: BoxDecoration(
                          color: AppTheme.ink.withOpacity(0.08),
                          borderRadius: BorderRadius.circular(10),
                        ),
                        child: Text(user.interestTags[i],
                            style: const TextStyle(fontSize: 11)),
                      ),
                    ),
                  ),
                ],
              ],
            ),
          ),
          const SizedBox(width: 8),
          Column(
            children: [
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                decoration: BoxDecoration(
                  color: scoreColor.withOpacity(0.12),
                  borderRadius: BorderRadius.circular(12),
                ),
                child: Text(
                  '${user.matchScore.toStringAsFixed(0)}%',
                  style: TextStyle(
                    fontSize: 14,
                    fontWeight: FontWeight.w800,
                    color: scoreColor,
                  ),
                ),
              ),
              const SizedBox(height: 4),
              Text('Match',
                  style: TextStyle(
                      fontSize: 10, color: scoreColor.withOpacity(0.8))),
            ],
          ),
        ],
      ),
    );
  }
}
