import 'package:flutter/material.dart';

import '../models/chat_model.dart';
import '../theme/app_theme.dart';
import '../widgets/chat_widgets.dart';
import 'chat_detail_page.dart';
import 'community_page.dart';
import 'family_page.dart';
import 'find_friends_page.dart';
import 'profile_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({this.initialTabIndex = 0, super.key});

  final int initialTabIndex;

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  late int _navIndex;
  String _selectedTab = 'All';

  @override
  void initState() {
    super.initState();
    _navIndex = widget.initialTabIndex;
  }

  List<Chat> get _filteredChats {
    return chats.where((c) {
      if (_selectedTab == 'Friends') return !c.isGroup;
      if (_selectedTab == 'Groups') return c.isGroup;
      return true;
    }).toList();
  }

  void _openFindFriends() {
    Navigator.of(
      context,
    ).push(MaterialPageRoute<void>(builder: (_) => const FindFriendsPage()));
  }

  @override
  Widget build(BuildContext context) {
    if (_navIndex == 1) {
      return Scaffold(
        backgroundColor: Colors.white,
        body: const CommunityPage(),
        bottomNavigationBar: BottomNav(
          selectedIndex: _navIndex,
          onSelected: (i) => setState(() => _navIndex = i),
        ),
      );
    }

    if (_navIndex == 2) {
      return Scaffold(
        backgroundColor: Colors.white,
        body: const FamilyPage(),
        bottomNavigationBar: BottomNav(
          selectedIndex: _navIndex,
          onSelected: (i) => setState(() => _navIndex = i),
        ),
      );
    }

    if (_navIndex == 3) {
      return Scaffold(
        backgroundColor: Colors.white,
        body: const ProfilePage(),
        bottomNavigationBar: BottomNav(
          selectedIndex: _navIndex,
          onSelected: (i) => setState(() => _navIndex = i),
        ),
      );
    }

    return Scaffold(
      backgroundColor: Colors.white,
      body: Column(
        children: [
          const Navbar(),
          const MessagesHeader(),
          _SearchBarButton(onTap: _openFindFriends),
          CategoryTabs(
            selected: _selectedTab,
            onSelected: (t) => setState(() => _selectedTab = t),
          ),
          const SizedBox(height: 4),
          Expanded(
            child: ChatList(
              chats: _filteredChats,
              onChatTap: (chat) {
                Navigator.of(context).push(
                  MaterialPageRoute<void>(
                    builder: (_) => ChatDetailPage(chat: chat),
                  ),
                );
              },
            ),
          ),
        ],
      ),
      bottomNavigationBar: BottomNav(
        selectedIndex: _navIndex,
        onSelected: (i) => setState(() => _navIndex = i),
      ),
    );
  }
}

class _SearchBarButton extends StatelessWidget {
  final VoidCallback onTap;
  const _SearchBarButton({required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(horizontal: 20, vertical: 8),
      child: GestureDetector(
        onTap: onTap,
        child: Container(
          height: 40,
          decoration: BoxDecoration(
            color: const Color(0xFFF0F1F3),
            borderRadius: BorderRadius.circular(20),
          ),
          child: const Row(
            children: [
              Padding(
                padding: EdgeInsets.only(left: 14),
                child: Icon(Icons.search, color: Color(0xFF9A9A9A), size: 20),
              ),
              SizedBox(width: 8),
              Text(
                'Search',
                style: TextStyle(color: Color(0xFF9A9A9A), fontSize: 15),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
