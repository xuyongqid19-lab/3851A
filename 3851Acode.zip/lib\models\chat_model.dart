class Chat {
  final String name;
  final String time;
  final int unreadCount;
  final String preview;
  final bool isGroup;
  final String category;

  const Chat({
    required this.name,
    required this.time,
    required this.unreadCount,
    required this.preview,
    this.isGroup = false,
    this.category = 'All',
  });
}

class Message {
  final String text;
  final String time;
  final bool isIncoming;
  final bool isLocation;

  const Message({
    required this.text,
    required this.time,
    this.isIncoming = true,
    this.isLocation = false,
  });
}

const chats = [
  Chat(
    name: 'Alex Tan',
    time: '10:30 AM',
    unreadCount: 2,
    preview: 'Hey! Are you joining the basketball game this weekend?',
  ),
  Chat(
    name: 'Basketball Buddies',
    time: '9:15 AM',
    unreadCount: 5,
    preview: 'Jason: See you all at 4pm!',
    isGroup: true,
    category: 'Groups',
  ),
  Chat(
    name: 'Emily Lim',
    time: 'Yesterday',
    unreadCount: 0,
    preview: 'Thanks for sharing the info!',
  ),
  Chat(
    name: 'Volunteer Team',
    time: 'Yesterday',
    unreadCount: 1,
    preview: 'Sarah: New event this Saturday.',
    isGroup: true,
    category: 'Groups',
  ),
  Chat(
    name: 'Mom',
    time: 'Yesterday',
    unreadCount: 0,
    preview: "Don't forget to check in today \u{1F60A}",
  ),
  Chat(
    name: 'David Lee',
    time: 'Mon',
    unreadCount: 0,
    preview: "Great! Let's meet up soon.",
  ),
  Chat(
    name: 'Hiking Club',
    time: 'Mon',
    unreadCount: 0,
    preview: 'Photo',
    isGroup: true,
    category: 'Groups',
  ),
];

final chatMessages = <String, List<Message>>{
  'Alex Tan': const [
    Message(text: 'Hey! How have you been?', time: '10:15 AM', isIncoming: true),
    Message(text: 'I\'m good, thanks! Busy with work lately.', time: '10:18 AM', isIncoming: false),
    Message(text: 'Same here! By the way, are you joining the basketball game this weekend?', time: '10:22 AM', isIncoming: true),
    Message(text: 'What time is it?', time: '10:25 AM', isIncoming: false),
    Message(text: '4pm at the community court. Should be fun!', time: '10:27 AM', isIncoming: true),
    Message(text: 'Sure, count me in! 🏀', time: '10:30 AM', isIncoming: false),
    Message(text: 'Hey! Are you joining the basketball game this weekend?', time: '10:30 AM', isIncoming: true),
  ],
  'Basketball Buddies': const [
    Message(text: 'Jason: Practice this Saturday at 4pm!', time: '9:00 AM', isIncoming: true),
    Message(text: 'Mike: I\'ll be there!', time: '9:05 AM', isIncoming: true),
    Message(text: 'Sounds good, see you all there!', time: '9:10 AM', isIncoming: false),
    Message(text: 'Jason: See you all at 4pm!', time: '9:15 AM', isIncoming: true),
  ],
  'Emily Lim': const [
    Message(text: 'Hey Emily, thanks for your help yesterday!', time: 'Yesterday', isIncoming: false),
    Message(text: 'You\'re welcome! Glad I could help 😊', time: 'Yesterday', isIncoming: true),
    Message(text: 'Thanks for sharing the info!', time: 'Yesterday', isIncoming: false),
  ],
  'Volunteer Team': const [
    Message(text: 'Sarah: We need volunteers for the community clean-up.', time: 'Yesterday', isIncoming: true),
    Message(text: 'I can help on Saturday morning!', time: 'Yesterday', isIncoming: false),
    Message(text: 'Sarah: Great! Meet at the park at 8am.', time: 'Yesterday', isIncoming: true),
    Message(text: 'Sarah: New event this Saturday.', time: 'Yesterday', isIncoming: true),
  ],
  'Mom': const [
    Message(text: 'Hi Mom! How are you?', time: 'Yesterday', isIncoming: false),
    Message(text: 'I\'m doing well, dear! Have you eaten?', time: 'Yesterday', isIncoming: true),
    Message(text: 'Yes, just had dinner. How about you?', time: 'Yesterday', isIncoming: false),
    Message(text: 'Don\'t forget to check in today 😊', time: 'Yesterday', isIncoming: true),
  ],
  'David Lee': const [
    Message(text: 'Hey David, long time no see!', time: 'Mon', isIncoming: false),
    Message(text: 'I know! We should catch up sometime.', time: 'Mon', isIncoming: true),
    Message(text: 'Great! Let\'s meet up soon.', time: 'Mon', isIncoming: false),
  ],
  'Hiking Club': const [
    Message(text: 'Amazing sunrise from the summit today! 🌄', time: 'Mon', isIncoming: true),
    Message(text: 'The Pine Ridge Trail location card:', time: 'Mon', isIncoming: true),
    Message(text: 'Pine Ridge Trail', time: 'Mon', isIncoming: true, isLocation: true),
    Message(text: 'Photo', time: 'Mon', isIncoming: true),
  ],
};
