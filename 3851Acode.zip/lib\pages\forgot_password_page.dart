import 'package:flutter/material.dart';

import '../theme/app_theme.dart';
import '../widgets/auth_widgets.dart';
import '../widgets/mobile_page_shell.dart';

enum RecoveryMethod { email, phone, securityQuestion }

class ForgotPasswordPage extends StatefulWidget {
  const ForgotPasswordPage({super.key});

  @override
  State<ForgotPasswordPage> createState() => _ForgotPasswordPageState();
}

class _ForgotPasswordPageState extends State<ForgotPasswordPage> {
  final _formKey = GlobalKey<FormState>();
  final _emailController = TextEditingController();
  final _phoneController = TextEditingController();
  final _codeController = TextEditingController();
  final _answerController = TextEditingController();
  final _newPasswordController = TextEditingController();
  final _confirmPasswordController = TextEditingController();

  RecoveryMethod _method = RecoveryMethod.email;
  String? _selectedQuestion;

  static const _securityQuestions = <String>[
    'What is the name of your first school?',
    'What is your favourite food?',
    'What city were you born in?',
    'What is your childhood nickname?',
  ];

  @override
  void dispose() {
    _emailController.dispose();
    _phoneController.dispose();
    _codeController.dispose();
    _answerController.dispose();
    _newPasswordController.dispose();
    _confirmPasswordController.dispose();
    super.dispose();
  }

  String? _required(String? value) {
    if (value == null || value.trim().isEmpty) {
      return 'This field is required.';
    }
    return null;
  }

  String? _validateCode(String? value) {
    final requiredError = _required(value);
    if (requiredError != null) return requiredError;
    return RegExp(r'^\d{6}$').hasMatch(value!.trim())
        ? null
        : 'Enter the 6-digit code.';
  }

  String? _validatePassword(String? value) {
    final requiredError = _required(value);
    if (requiredError != null) return requiredError;
    return value!.length >= 6 ? null : 'Use at least 6 characters.';
  }

  String? _validateConfirmPassword(String? value) {
    final requiredError = _required(value);
    if (requiredError != null) return requiredError;
    return value == _newPasswordController.text ? null : 'Passwords do not match.';
  }

  void _sendCode() {
    final target = _method == RecoveryMethod.email
        ? _emailController.text.trim()
        : _phoneController.text.trim();
    if (target.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(
            _method == RecoveryMethod.email
                ? 'Please enter your email address first.'
                : 'Please enter your phone number first.',
          ),
        ),
      );
      return;
    }

    // 演示版本不连接短信或邮件服务，只模拟发送成功。
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(
          _method == RecoveryMethod.email
              ? 'Verification code sent to your email.'
              : 'SMS verification code sent.',
        ),
      ),
    );
  }

  void _resetPassword() {
    FocusScope.of(context).unfocus();
    if (!(_formKey.currentState?.validate() ?? false)) return;

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Password reset successfully.')),
    );
    Navigator.of(context).pop();
  }

  String get _subtitle {
    switch (_method) {
      case RecoveryMethod.email:
        return 'Reset your password using your email address.';
      case RecoveryMethod.phone:
        return 'Reset your password using your phone number.';
      case RecoveryMethod.securityQuestion:
        return 'Reset your password using your security question.';
    }
  }

  @override
  Widget build(BuildContext context) {
    return MobilePageShell(
      child: Column(
        children: [
          const GlobalVillageHeader(showBackButton: true),
          Expanded(
            child: SingleChildScrollView(
              padding: const EdgeInsets.fromLTRB(22, 28, 22, 28),
              child: Form(
                key: _formKey,
                child: Column(
                  children: [
                    AuthPageTitle(title: 'Forgot Password', subtitle: _subtitle),
                    const SizedBox(height: 26),
                    _RecoveryTabs(
                      selected: _method,
                      onSelected: (method) {
                        setState(() => _method = method);
                      },
                    ),
                    const SizedBox(height: 16),
                    const _InformationBox(),
                    const SizedBox(height: 26),
                    AnimatedSwitcher(
                      duration: const Duration(milliseconds: 180),
                      child: _MethodFields(
                        key: ValueKey(_method),
                        method: _method,
                        emailController: _emailController,
                        phoneController: _phoneController,
                        codeController: _codeController,
                        answerController: _answerController,
                        selectedQuestion: _selectedQuestion,
                        questions: _securityQuestions,
                        onQuestionChanged: (value) {
                          setState(() => _selectedQuestion = value);
                        },
                        requiredValidator: _required,
                        codeValidator: _validateCode,
                        onSendCode: _sendCode,
                      ),
                    ),
                    const SizedBox(height: 20),
                    const FieldLabel('New Password'),
                    PasswordField(
                      controller: _newPasswordController,
                      hintText: 'Create a new password',
                      validator: _validatePassword,
                    ),
                    const SizedBox(height: 20),
                    const FieldLabel('Confirm Password'),
                    PasswordField(
                      controller: _confirmPasswordController,
                      hintText: 'Confirm your new password',
                      validator: _validateConfirmPassword,
                      textInputAction: TextInputAction.done,
                      onFieldSubmitted: (_) => _resetPassword(),
                    ),
                    const SizedBox(height: 24),
                    PrimaryButton(label: 'Reset Password', onPressed: _resetPassword),
                    const SizedBox(height: 6),
                    UnderlineTextButton(
                      label: 'Back to Login',
                      onPressed: () => Navigator.of(context).pop(),
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class _RecoveryTabs extends StatelessWidget {
  const _RecoveryTabs({required this.selected, required this.onSelected});

  final RecoveryMethod selected;
  final ValueChanged<RecoveryMethod> onSelected;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(3),
      decoration: BoxDecoration(
        color: const Color(0xFFF4F4F4),
        border: Border.all(color: AppTheme.border),
        borderRadius: BorderRadius.circular(8),
      ),
      child: Row(
        children: [
          Expanded(
            child: _TabButton(
              icon: Icons.mail_outline,
              label: 'Email',
              selected: selected == RecoveryMethod.email,
              onTap: () => onSelected(RecoveryMethod.email),
            ),
          ),
          Expanded(
            child: _TabButton(
              icon: Icons.phone_outlined,
              label: 'Phone',
              selected: selected == RecoveryMethod.phone,
              onTap: () => onSelected(RecoveryMethod.phone),
            ),
          ),
          Expanded(
            child: _TabButton(
              icon: Icons.shield_outlined,
              label: 'Security Question',
              selected: selected == RecoveryMethod.securityQuestion,
              onTap: () => onSelected(RecoveryMethod.securityQuestion),
            ),
          ),
        ],
      ),
    );
  }
}

class _TabButton extends StatelessWidget {
  const _TabButton({
    required this.icon,
    required this.label,
    required this.selected,
    required this.onTap,
  });

  final IconData icon;
  final String label;
  final bool selected;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: selected ? Colors.white : Colors.transparent,
      borderRadius: BorderRadius.circular(6),
      child: InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(6),
        child: Container(
          constraints: const BoxConstraints(minHeight: 48),
          padding: const EdgeInsets.symmetric(horizontal: 3, vertical: 7),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(6),
            boxShadow: selected
                ? const [
                    BoxShadow(
                      color: Color(0x18000000),
                      blurRadius: 4,
                      offset: Offset(0, 1),
                    ),
                  ]
                : null,
          ),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(icon, size: 19, color: AppTheme.ink),
              const SizedBox(width: 5),
              Flexible(
                child: Text(
                  label,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: TextStyle(
                    fontSize: 11.5,
                    fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _InformationBox extends StatelessWidget {
  const _InformationBox();

  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: const Color(0xFFF8F8F8),
        border: Border.all(color: const Color(0xFFE0E0E0)),
        borderRadius: BorderRadius.circular(7),
      ),
      child: const Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Icon(Icons.info_outline, size: 20, color: AppTheme.muted),
          SizedBox(width: 10),
          Expanded(
            child: Text(
              'Security Question verification is only available for users who set security questions and answers during registration.',
              style: TextStyle(color: AppTheme.muted, fontSize: 12.5, height: 1.4),
            ),
          ),
        ],
      ),
    );
  }
}

class _MethodFields extends StatelessWidget {
  const _MethodFields({
    required this.method,
    required this.emailController,
    required this.phoneController,
    required this.codeController,
    required this.answerController,
    required this.selectedQuestion,
    required this.questions,
    required this.onQuestionChanged,
    required this.requiredValidator,
    required this.codeValidator,
    required this.onSendCode,
    super.key,
  });

  final RecoveryMethod method;
  final TextEditingController emailController;
  final TextEditingController phoneController;
  final TextEditingController codeController;
  final TextEditingController answerController;
  final String? selectedQuestion;
  final List<String> questions;
  final ValueChanged<String?> onQuestionChanged;
  final String? Function(String?) requiredValidator;
  final String? Function(String?) codeValidator;
  final VoidCallback onSendCode;

  @override
  Widget build(BuildContext context) {
    if (method == RecoveryMethod.securityQuestion) {
      return Column(
        children: [
          const FieldLabel('Security Question'),
          DropdownButtonFormField<String>(
            value: selectedQuestion,
            isExpanded: true,
            validator: (value) => value == null ? 'Please select a question.' : null,
            decoration: const InputDecoration(hintText: 'Select your security question'),
            items: questions
                .map(
                  (question) => DropdownMenuItem<String>(
                    value: question,
                    child: Text(question, overflow: TextOverflow.ellipsis),
                  ),
                )
                .toList(),
            onChanged: onQuestionChanged,
          ),
          const SizedBox(height: 20),
          const FieldLabel('Answer'),
          TextFormField(
            controller: answerController,
            validator: requiredValidator,
            textInputAction: TextInputAction.next,
            decoration: const InputDecoration(hintText: 'Enter your answer'),
          ),
        ],
      );
    }

    final isEmail = method == RecoveryMethod.email;
    return Column(
      children: [
        FieldLabel(isEmail ? 'Email Address' : 'Phone Number'),
        TextFormField(
          controller: isEmail ? emailController : phoneController,
          validator: requiredValidator,
          keyboardType: isEmail ? TextInputType.emailAddress : TextInputType.phone,
          textInputAction: TextInputAction.next,
          decoration: InputDecoration(
            hintText: isEmail ? 'Enter your email' : 'Enter your phone number',
          ),
        ),
        const SizedBox(height: 18),
        OutlineActionButton(
          label: isEmail ? 'Send Code' : 'Send SMS Code',
          onPressed: onSendCode,
        ),
        const SizedBox(height: 20),
        const FieldLabel('Verification Code'),
        TextFormField(
          controller: codeController,
          validator: codeValidator,
          keyboardType: TextInputType.number,
          maxLength: 6,
          textInputAction: TextInputAction.next,
          decoration: const InputDecoration(
            hintText: 'Enter the 6-digit code',
            counterText: '',
          ),
        ),
      ],
    );
  }
}
