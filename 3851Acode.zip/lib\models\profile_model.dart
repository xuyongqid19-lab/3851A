import 'package:flutter/foundation.dart';

class ProfileData {
  final String name;
  final String username;
  final int age;
  final String email;
  final String phone;
  final String community;
  final String address;
  final List<String> interestTags;

  const ProfileData({
    required this.name,
    required this.username,
    required this.age,
    required this.email,
    required this.phone,
    this.community = '',
    this.address = '',
    this.interestTags = const [],
  });

  ProfileData copyWith({
    String? name,
    String? username,
    int? age,
    String? email,
    String? phone,
    String? community,
    String? address,
    List<String>? interestTags,
  }) {
    return ProfileData(
      name: name ?? this.name,
      username: username ?? this.username,
      age: age ?? this.age,
      email: email ?? this.email,
      phone: phone ?? this.phone,
      community: community ?? this.community,
      address: address ?? this.address,
      interestTags: interestTags ?? this.interestTags,
    );
  }
}

class MatchUser {
  final String name;
  final int age;
  final String community;
  final String address;
  final List<String> interestTags;
  final String avatarInitial;
  final double matchScore;

  const MatchUser({
    required this.name,
    required this.age,
    this.community = '',
    this.address = '',
    this.interestTags = const [],
    required this.avatarInitial,
    this.matchScore = 0,
  });
}

final availableInterests = [
  'Hiking', 'Photography', 'Basketball', 'Cooking', 'Travel',
  'Yoga', 'Gaming', 'Music', 'Art', 'Running',
  'Swimming', 'Cycling', 'Reading', 'Writing', 'Dancing',
  'Movies', 'Gardening', 'Fishing', 'Painting', 'Singing',
];

final availableCommunities = [
  'Riverside', 'Central Park', 'Downtown', 'Sunset Village',
  'Pine Ridge', 'Lakeview', 'Greenwood', 'Oakville',
];

final ValueNotifier<ProfileData> currentProfile = ValueNotifier<ProfileData>(
  const ProfileData(
    name: 'You',
    username: '@you',
    age: 25,
    email: 'you@example.com',
    phone: '+1 234 567 8900',
    community: 'Riverside',
    address: '123 Main St, Riverside',
    interestTags: ['Hiking', 'Photography', 'Music'],
  ),
);

final matchUsers = <MatchUser>[
  MatchUser(
    name: 'Alex Johnson', age: 27, community: 'Riverside',
    address: '456 Oak Ave, Riverside',
    interestTags: ['Hiking', 'Photography', 'Basketball'],
    avatarInitial: 'A',
  ),
  MatchUser(
    name: 'Sophie Chen', age: 24, community: 'Central Park',
    address: '789 Pine St, Central Park',
    interestTags: ['Cooking', 'Travel', 'Yoga'],
    avatarInitial: 'S',
  ),
  MatchUser(
    name: 'Liam Brown', age: 29, community: 'Downtown',
    address: '321 Elm St, Downtown',
    interestTags: ['Gaming', 'Music', 'Basketball'],
    avatarInitial: 'L',
  ),
  MatchUser(
    name: 'Emma Wang', age: 23, community: 'Sunset Village',
    address: '654 Birch Ln, Sunset Village',
    interestTags: ['Art', 'Photography', 'Movies'],
    avatarInitial: 'E',
  ),
  MatchUser(
    name: 'Noah Lee', age: 28, community: 'Riverside',
    address: '987 Cedar Dr, Riverside',
    interestTags: ['Running', 'Swimming', 'Cycling'],
    avatarInitial: 'N',
  ),
  MatchUser(
    name: 'Olivia Tan', age: 26, community: 'Pine Ridge',
    address: '147 Walnut Ct, Pine Ridge',
    interestTags: ['Reading', 'Writing', 'Yoga'],
    avatarInitial: 'O',
  ),
  MatchUser(
    name: 'James Wong', age: 30, community: 'Lakeview',
    address: '258 Spruce Way, Lakeview',
    interestTags: ['Cooking', 'Travel', 'Photography'],
    avatarInitial: 'J',
  ),
  MatchUser(
    name: 'Mia Patel', age: 22, community: 'Greenwood',
    address: '369 Ash Blvd, Greenwood',
    interestTags: ['Dancing', 'Music', 'Art'],
    avatarInitial: 'M',
  ),
  MatchUser(
    name: 'Ethan Kim', age: 31, community: 'Oakville',
    address: '159 Maple Dr, Oakville',
    interestTags: ['Fishing', 'Gardening', 'Hiking'],
    avatarInitial: 'E',
  ),
  MatchUser(
    name: 'Ava Martinez', age: 25, community: 'Downtown',
    address: '753 Cherry Ln, Downtown',
    interestTags: ['Yoga', 'Reading', 'Movies'],
    avatarInitial: 'A',
  ),
];

List<MatchUser> interestMatch(ProfileData profile) {
  final scored = matchUsers.map((user) {
    final shared = profile.interestTags
        .where((tag) => user.interestTags.contains(tag))
        .length;
    final max = profile.interestTags.isEmpty
        ? 1
        : (profile.interestTags.length + user.interestTags.length) ~/ 2;
    final ageDiff = (profile.age - user.age).abs();
    final ageBonus = ageDiff <= 5 ? 0.2 : (ageDiff <= 10 ? 0.1 : 0);
    final score = (max > 0 ? shared / max : 0) + ageBonus;
    return MatchUser(
      name: user.name,
      age: user.age,
      community: user.community,
      address: user.address,
      interestTags: user.interestTags,
      avatarInitial: user.avatarInitial,
      matchScore: double.parse((score.clamp(0, 1) * 100).toStringAsFixed(0)),
    );
  }).toList();
  scored.sort((a, b) => b.matchScore.compareTo(a.matchScore));
  return scored;
}

List<MatchUser> recommendMatch(ProfileData profile) {
  final scored = matchUsers.map((user) {
    double score = 0;
    if (user.community == profile.community) score += 0.4;
    final ageDiff = (profile.age - user.age).abs();
    if (ageDiff <= 3) score += 0.3;
    else if (ageDiff <= 7) score += 0.15;
    final shared = profile.interestTags
        .where((tag) => user.interestTags.contains(tag))
        .length;
    score += shared * 0.1;
    return MatchUser(
      name: user.name,
      age: user.age,
      community: user.community,
      address: user.address,
      interestTags: user.interestTags,
      avatarInitial: user.avatarInitial,
      matchScore: double.parse((score.clamp(0, 1) * 100).toStringAsFixed(0)),
    );
  }).toList();
  scored.sort((a, b) => b.matchScore.compareTo(a.matchScore));
  return scored;
}
