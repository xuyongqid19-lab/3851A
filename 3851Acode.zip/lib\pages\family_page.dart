import 'package:flutter/material.dart';

import '../models/family_model.dart';
import '../theme/app_theme.dart';
import '../widgets/chat_widgets.dart';
import 'home_page.dart';

class FamilyPage extends StatelessWidget {
  // 创建 Family 总览页面。
  const FamilyPage({super.key});

  // 构建 Family 总览内容。
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        const _FamilyHeader(familyTitle: 'Family'),
        Expanded(
          child: ListView(
            padding: const EdgeInsets.fromLTRB(28, 18, 28, 28),
            children: [
              const Text(
                'Family Overview',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w800,
                  color: AppTheme.ink,
                ),
              ),
              const SizedBox(height: 18),
              const Text(
                'Private family space for care and safety.',
                textAlign: TextAlign.center,
                style: TextStyle(fontSize: 12, color: AppTheme.muted),
              ),
              const SizedBox(height: 40),
              _FamilyOverviewCard(
                familyCode: 'ACa',
                familyTitle: 'Your Family',
                familySubtitle: 'Group avatar, admins, members\nand history',
                familyOnTap: () => Navigator.of(context).push(
                  MaterialPageRoute<void>(
                    builder: (_) => const FamilyYourFamilyPage(),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              _FamilyOverviewCard(
                familyCode: 'ACb',
                familyTitle: 'Member Status',
                familySubtitle:
                    'Check-in records, activity\nstate, health notes',
                familyOnTap: () => Navigator.of(context).push(
                  MaterialPageRoute<void>(
                    builder: (_) => const FamilyMemberStatusPage(),
                  ),
                ),
              ),
              const SizedBox(height: 20),
              _FamilyOverviewCard(
                familyCode: 'ACc',
                familyTitle: 'Family Activities',
                familySubtitle: 'Family events, history and\ncreation tools',
                familyOnTap: () => Navigator.of(context).push(
                  MaterialPageRoute<void>(
                    builder: (_) => const FamilyActivitiesPage(),
                  ),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}

class FamilyYourFamilyPage extends StatelessWidget {
  // 创建家庭详情页面。
  const FamilyYourFamilyPage({super.key});

  // 构建家庭详情内容。
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [
            const _FamilyHeader(
              familyTitle: 'Your Family',
              familyShowBack: true,
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(28, 24, 28, 28),
                children: [
                  const Center(
                    child: Stack(
                      clipBehavior: Clip.none,
                      children: [
                        _FamilyCircleBadge(
                          familyLabel: 'F',
                          familySize: 54,
                          familyMutedBorder: true,
                        ),
                        Positioned(
                          right: 2,
                          bottom: 4,
                          child: _FamilyDot(familyColor: Colors.green),
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 18),
                  const Text(
                    FamilyDataStore.familyGroupName,
                    textAlign: TextAlign.center,
                    style: TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w800,
                      color: AppTheme.ink,
                    ),
                  ),
                  const SizedBox(height: 8),
                  const Text(
                    FamilyDataStore.familyGroupSubtitle,
                    textAlign: TextAlign.center,
                    style: TextStyle(fontSize: 13, color: AppTheme.muted),
                  ),
                  const SizedBox(height: 34),
                  const _FamilyInfoCard(
                    familyCode: 'i',
                    familyTitle: 'Family Details',
                    familySubtitle: FamilyDataStore.familyDetails,
                  ),
                  const SizedBox(height: 18),
                  const _FamilyInfoCard(
                    familyCode: 'A',
                    familyTitle: 'Admins',
                    familySubtitle: FamilyDataStore.familyAdmins,
                  ),
                  const SizedBox(height: 18),
                  _FamilyInfoCard(
                    familyCode: 'M',
                    familyTitle: 'Manage Members',
                    familySubtitle: 'View and manage Mom, Dad, Grandfather',
                    familyActionLabel: 'View',
                    familyOnAction: () => Navigator.of(context).push(
                      MaterialPageRoute<void>(
                        builder: (_) => const FamilyMemberStatusPage(),
                      ),
                    ),
                  ),
                  const SizedBox(height: 18),
                  _FamilyInfoCard(
                    familyCode: 'H',
                    familyTitle: 'Family History',
                    familySubtitle: 'See previous family events and notes',
                    familyActionLabel: 'Open',
                    familyOnAction: () => Navigator.of(context).push(
                      MaterialPageRoute<void>(
                        builder: (_) => const FamilyActivitiesPage(),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNav(
                  selectedIndex: 2,
                  onSelected: (i) => Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(builder: (_) => HomePage(initialTabIndex: i)),
                    (route) => false,
                  ),
                ),
    );
  }
}

class FamilyMemberStatusPage extends StatelessWidget {
  // 创建成员状态页面。
  const FamilyMemberStatusPage({super.key});

  // 打开创建打卡任务页面。
  void familyOpenCreateTask(BuildContext context) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) => const FamilyCreateCheckInTaskPage(),
      ),
    );
  }

  // 打开健康记录弹窗。
  void familyOpenHealthRecordDialog(BuildContext context) {
    showDialog<void>(
      context: context,
      builder: (_) => const _FamilyHealthRecordDialog(),
    );
  }

  // 构建成员状态内容。
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [
            _FamilyHeader(
              familyTitle: 'Member Status',
              familyShowBack: true,
              familyActionIcon: Icons.add,
              familyOnAction: () => familyOpenCreateTask(context),
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(28, 18, 28, 28),
                children: [
                  const _FamilySectionTitle(familyTitle: 'Today Status'),
                  const SizedBox(height: 18),
                  ValueListenableBuilder<List<FamilyMember>>(
                    valueListenable: FamilyDataStore.familyMembersNotifier,
                    builder: (context, familyMembers, _) {
                      return Column(
                        children: [
                          for (final familyMember in familyMembers) ...[
                            _FamilyMemberStatusCard(familyMember: familyMember),
                            const SizedBox(height: 18),
                          ],
                        ],
                      );
                    },
                  ),
                  ValueListenableBuilder<List<FamilyCheckInTask>>(
                    valueListenable: FamilyDataStore.familyCheckInTasksNotifier,
                    builder: (context, familyTasks, _) {
                      if (familyTasks.isEmpty) return const SizedBox.shrink();
                      return Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          const SizedBox(height: 18),
                          const _FamilySectionTitle(
                            familyTitle: 'Created Check-in Tasks',
                          ),
                          const SizedBox(height: 12),
                          for (final familyTask in familyTasks) ...[
                            _FamilyTaskCard(familyTask: familyTask),
                            const SizedBox(height: 12),
                          ],
                        ],
                      );
                    },
                  ),
                  const SizedBox(height: 30),
                  const _FamilySectionTitle(familyTitle: 'Admin Notes'),
                  const SizedBox(height: 14),
                  ValueListenableBuilder<List<FamilyHealthRecord>>(
                    valueListenable:
                        FamilyDataStore.familyHealthRecordsNotifier,
                    builder: (context, familyRecords, _) {
                      return Column(
                        children: [
                          for (final familyRecord in familyRecords) ...[
                            _FamilyHealthRecordCard(
                              familyRecord: familyRecord,
                              familyOnTap: () =>
                                  familyOpenHealthRecordDialog(context),
                            ),
                            const SizedBox(height: 12),
                          ],
                        ],
                      );
                    },
                  ),
                  const SizedBox(height: 26),
                  _FamilyPrimaryButton(
                    familyLabel: '+ Create Check-in Task',
                    familyOnPressed: () => familyOpenCreateTask(context),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNav(
                  selectedIndex: 2,
                  onSelected: (i) => Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(builder: (_) => HomePage(initialTabIndex: i)),
                    (route) => false,
                  ),
                ),
    );
  }
}

class FamilyCreateCheckInTaskPage extends StatefulWidget {
  // 创建家庭打卡任务页面。
  const FamilyCreateCheckInTaskPage({super.key});

  // 创建页面状态。
  @override
  State<FamilyCreateCheckInTaskPage> createState() =>
      _FamilyCreateCheckInTaskPageState();
}

class _FamilyCreateCheckInTaskPageState
    extends State<FamilyCreateCheckInTaskPage> {
  final TextEditingController _familyTitleController = TextEditingController();
  final TextEditingController _familyRepeatController = TextEditingController(
    text: 'Every day',
  );
  final Set<String> _familySelectedMembers = {};
  FamilyCheckInType _familySelectedType = FamilyCheckInType.autoLogin;

  // 释放输入框控制器。
  @override
  void dispose() {
    _familyTitleController.dispose();
    _familyRepeatController.dispose();
    super.dispose();
  }

  // 切换成员选择状态。
  void familyToggleMember(String familyRole) {
    setState(() {
      if (_familySelectedMembers.contains(familyRole)) {
        _familySelectedMembers.remove(familyRole);
      } else {
        _familySelectedMembers.add(familyRole);
      }
    });
  }

  // 保存家庭打卡任务。
  void familyCreateTask() {
    if (_familySelectedMembers.isEmpty) {
      _familyShowSnack(context, 'Select at least one family member.');
      return;
    }

    final familyTask = FamilyCheckInTask(
      familyTitle: _familyTextOrDefault(
        _familyTitleController.text,
        'Daily safety check-in',
      ),
      familyMemberNames: _familySelectedMembers.toList(),
      familyType: _familySelectedType,
      familyRepeat: _familyTextOrDefault(
        _familyRepeatController.text,
        'Every day',
      ),
      familyCreatedAt: DateTime.now(),
    );
    FamilyDataStore.familyAddCheckInTask(familyTask);
    Navigator.of(context).pop();
  }

  // 构建创建打卡任务表单。
  @override
  Widget build(BuildContext context) {
    final familyRoles = FamilyDataStore.familyMembers().map(
      (member) => member.familyRole,
    );

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [
            const _FamilyHeader(
              familyTitle: 'Create Check-in Task',
              familyShowBack: true,
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(28, 12, 28, 28),
                children: [
                  const _FamilyFieldLabel(familyLabel: 'Task Title'),
                  _FamilyTextField(
                    familyController: _familyTitleController,
                    familyHint: 'Daily safety check-in',
                  ),
                  const SizedBox(height: 34),
                  const _FamilyFieldLabel(familyLabel: 'Family Members'),
                  const SizedBox(height: 8),
                  for (final familyRole in familyRoles)
                    _FamilyCheckboxRow(
                      familyLabel: familyRole,
                      familySelected: _familySelectedMembers.contains(
                        familyRole,
                      ),
                      familyOnTap: () => familyToggleMember(familyRole),
                    ),
                  const SizedBox(height: 28),
                  const _FamilyFieldLabel(familyLabel: 'Check-in Type'),
                  const SizedBox(height: 12),
                  for (final familyType in FamilyCheckInType.values) ...[
                    _FamilyRadioCard(
                      familyLabel: familyType.familyLabel,
                      familySelected: _familySelectedType == familyType,
                      familyOnTap: () {
                        setState(() => _familySelectedType = familyType);
                      },
                    ),
                    const SizedBox(height: 12),
                  ],
                  const SizedBox(height: 10),
                  const _FamilyFieldLabel(familyLabel: 'Repeat'),
                  _FamilyTextField(
                    familyController: _familyRepeatController,
                    familyHint: 'Every day',
                  ),
                  const SizedBox(height: 30),
                  _FamilyPrimaryButton(
                    familyLabel: 'Create Task',
                    familyOnPressed: familyCreateTask,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNav(
                  selectedIndex: 2,
                  onSelected: (i) => Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(builder: (_) => HomePage(initialTabIndex: i)),
                    (route) => false,
                  ),
                ),
    );
  }
}

class FamilyActivitiesPage extends StatelessWidget {
  // 创建家庭活动列表页面。
  const FamilyActivitiesPage({super.key});

  // 打开创建家庭活动页面。
  void familyOpenCreateActivity(BuildContext context) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(builder: (_) => const FamilyCreateActivityPage()),
    );
  }

  // 打开家庭活动详情页面。
  void familyOpenActivityDetail(
    BuildContext context,
    FamilyActivity familyActivity,
  ) {
    Navigator.of(context).push(
      MaterialPageRoute<void>(
        builder: (_) =>
            FamilyActivityDetailPage(familyActivity: familyActivity),
      ),
    );
  }

  // 构建家庭活动列表。
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [
            _FamilyHeader(
              familyTitle: 'Family Activities',
              familyShowBack: true,
              familyActionIcon: Icons.add,
              familyOnAction: () => familyOpenCreateActivity(context),
            ),
            Expanded(
              child: ValueListenableBuilder<List<FamilyActivity>>(
                valueListenable: FamilyDataStore.familyActivitiesNotifier,
                builder: (context, familyActivities, _) {
                  final familyRecentActivities = familyActivities
                      .where((familyActivity) => familyActivity.familyIsRecent)
                      .toList();
                  final familyHistoryActivities = familyActivities
                      .where((familyActivity) => !familyActivity.familyIsRecent)
                      .toList();

                  return ListView(
                    padding: const EdgeInsets.fromLTRB(28, 18, 28, 28),
                    children: [
                      const _FamilySectionTitle(
                        familyTitle: 'Recent Family Activity',
                      ),
                      const SizedBox(height: 18),
                      for (final familyActivity in familyRecentActivities) ...[
                        _FamilyActivityCard(
                          familyActivity: familyActivity,
                          familyActionLabel: 'View',
                          familyOnTap: () =>
                              familyOpenActivityDetail(context, familyActivity),
                        ),
                        const SizedBox(height: 18),
                      ],
                      const SizedBox(height: 18),
                      const _FamilySectionTitle(familyTitle: 'History'),
                      const SizedBox(height: 18),
                      for (final familyActivity in familyHistoryActivities) ...[
                        _FamilyActivityCard(
                          familyActivity: familyActivity,
                          familyActionLabel: 'Open',
                          familyOnTap: () =>
                              familyOpenActivityDetail(context, familyActivity),
                        ),
                        const SizedBox(height: 18),
                      ],
                      const SizedBox(height: 18),
                      _FamilyPrimaryButton(
                        familyLabel: '+ Create Family Activity',
                        familyOnPressed: () =>
                            familyOpenCreateActivity(context),
                      ),
                    ],
                  );
                },
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNav(
                  selectedIndex: 2,
                  onSelected: (i) => Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(builder: (_) => HomePage(initialTabIndex: i)),
                    (route) => false,
                  ),
                ),
    );
  }
}

class FamilyActivityDetailPage extends StatelessWidget {
  // 创建家庭活动详情页面。
  const FamilyActivityDetailPage({required this.familyActivity, super.key});

  final FamilyActivity familyActivity;

  // 构建家庭活动详情。
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [
            const _FamilyHeader(
              familyTitle: 'Family Activity',
              familyShowBack: true,
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(28, 22, 28, 28),
                children: [
                  Text(
                    familyActivity.familyTitle,
                    style: const TextStyle(
                      fontSize: 24,
                      fontWeight: FontWeight.w800,
                      color: AppTheme.ink,
                    ),
                  ),
                  const SizedBox(height: 14),
                  _FamilyDetailRow(
                    familyLabel: 'Date',
                    familyValue: familyActivity.familyDate,
                  ),
                  _FamilyDetailRow(
                    familyLabel: 'Duration',
                    familyValue: familyActivity.familyDuration,
                  ),
                  _FamilyDetailRow(
                    familyLabel: 'Location',
                    familyValue: familyActivity.familyLocation,
                  ),
                  _FamilyDetailRow(
                    familyLabel: 'Participants',
                    familyValue: familyActivity.familyParticipantSummary,
                  ),
                  _FamilyDetailRow(
                    familyLabel: 'Goal',
                    familyValue: familyActivity.familyGoal,
                  ),
                  _FamilyDetailRow(
                    familyLabel: 'Content',
                    familyValue: familyActivity.familyDescription,
                  ),
                  _FamilyDetailRow(
                    familyLabel: 'Requirements',
                    familyValue: familyActivity.familyRequirements,
                  ),
                  const SizedBox(height: 14),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      for (final familyTag in familyActivity.familyTags)
                        _FamilyTag(familyLabel: familyTag),
                    ],
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNav(
                  selectedIndex: 2,
                  onSelected: (i) => Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(builder: (_) => HomePage(initialTabIndex: i)),
                    (route) => false,
                  ),
                ),
    );
  }
}

class FamilyCreateActivityPage extends StatefulWidget {
  // 创建家庭活动创建页面。
  const FamilyCreateActivityPage({super.key});

  // 创建页面状态。
  @override
  State<FamilyCreateActivityPage> createState() =>
      _FamilyCreateActivityPageState();
}

class _FamilyCreateActivityPageState extends State<FamilyCreateActivityPage> {
  final TextEditingController _familyTitleController = TextEditingController();
  final TextEditingController _familyDateController = TextEditingController();
  final TextEditingController _familyDurationController =
      TextEditingController();
  final TextEditingController _familyLocationController =
      TextEditingController();
  final TextEditingController _familyGoalController = TextEditingController();
  final TextEditingController _familyDescriptionController =
      TextEditingController();
  final TextEditingController _familyRequirementsController =
      TextEditingController();
  final TextEditingController _familyTagsController = TextEditingController();
  final Set<String> _familySelectedParticipants = {'Mom'};

  // 释放输入框控制器。
  @override
  void dispose() {
    _familyTitleController.dispose();
    _familyDateController.dispose();
    _familyDurationController.dispose();
    _familyLocationController.dispose();
    _familyGoalController.dispose();
    _familyDescriptionController.dispose();
    _familyRequirementsController.dispose();
    _familyTagsController.dispose();
    super.dispose();
  }

  // 切换参与者选择状态。
  void familyToggleParticipant(String familyRole) {
    setState(() {
      if (_familySelectedParticipants.contains(familyRole)) {
        _familySelectedParticipants.remove(familyRole);
      } else {
        _familySelectedParticipants.add(familyRole);
      }
    });
  }

  // 保存家庭活动。
  void familyCreateActivity() {
    if (_familySelectedParticipants.isEmpty) {
      _familyShowSnack(context, 'Select at least one participant.');
      return;
    }

    final familyTags = _familyTagsController.text
        .split(',')
        .map((familyTag) => familyTag.trim())
        .where((familyTag) => familyTag.isNotEmpty)
        .toList();

    final familyActivity = FamilyActivity(
      familyTitle: _familyTextOrDefault(
        _familyTitleController.text,
        'Family Activity',
      ),
      familyDate: _familyTextOrDefault(
        _familyDateController.text,
        'Select date',
      ),
      familyDuration: _familyTextOrDefault(
        _familyDurationController.text,
        '1 hour',
      ),
      familyLocation: _familyTextOrDefault(
        _familyLocationController.text,
        'Home',
      ),
      familyParticipants: _familySelectedParticipants.toList(),
      familyGoal: _familyTextOrDefault(
        _familyGoalController.text,
        'Care together',
      ),
      familyDescription: _familyTextOrDefault(
        _familyDescriptionController.text,
        'Describe activity content and requirements.',
      ),
      familyRequirements: _familyTextOrDefault(
        _familyRequirementsController.text,
        'No extra requirements.',
      ),
      familyTags: familyTags.isEmpty ? ['Family'] : familyTags,
      familyIsRecent: true,
    );
    FamilyDataStore.familyAddActivity(familyActivity);
    Navigator.of(context).pop();
  }

  // 构建创建家庭活动表单。
  @override
  Widget build(BuildContext context) {
    final familyRoles = FamilyDataStore.familyMembers().map(
      (member) => member.familyRole,
    );

    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Column(
          children: [
            const _FamilyHeader(
              familyTitle: 'Create Family Activity',
              familyShowBack: true,
            ),
            Expanded(
              child: ListView(
                padding: const EdgeInsets.fromLTRB(28, 12, 28, 28),
                children: [
                  const _FamilyFieldLabel(familyLabel: 'Activity Title'),
                  _FamilyTextField(
                    familyController: _familyTitleController,
                    familyHint: 'Enter family activity title',
                  ),
                  const SizedBox(height: 16),
                  const _FamilyFieldLabel(familyLabel: 'Date'),
                  _FamilyTextField(
                    familyController: _familyDateController,
                    familyHint: 'Select date',
                  ),
                  const SizedBox(height: 16),
                  const _FamilyFieldLabel(familyLabel: 'Duration'),
                  _FamilyTextField(
                    familyController: _familyDurationController,
                    familyHint: 'Estimated time length',
                  ),
                  const SizedBox(height: 16),
                  const _FamilyFieldLabel(familyLabel: 'Location'),
                  _FamilyTextField(
                    familyController: _familyLocationController,
                    familyHint: 'Enter location',
                  ),
                  const SizedBox(height: 28),
                  const _FamilyFieldLabel(familyLabel: 'Participants'),
                  const SizedBox(height: 10),
                  Wrap(
                    spacing: 8,
                    runSpacing: 8,
                    children: [
                      for (final familyRole in familyRoles)
                        _FamilySelectableTag(
                          familyLabel: familyRole,
                          familySelected: _familySelectedParticipants.contains(
                            familyRole,
                          ),
                          familyOnTap: () =>
                              familyToggleParticipant(familyRole),
                        ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  const _FamilyFieldLabel(familyLabel: 'Goal'),
                  _FamilyTextField(
                    familyController: _familyGoalController,
                    familyHint: 'What is the goal?',
                    familyMaxLines: 2,
                  ),
                  const SizedBox(height: 16),
                  const _FamilyFieldLabel(familyLabel: 'Description'),
                  _FamilyTextField(
                    familyController: _familyDescriptionController,
                    familyHint: 'Describe activity content...',
                    familyMaxLines: 3,
                  ),
                  const SizedBox(height: 16),
                  const _FamilyFieldLabel(familyLabel: 'Requirements'),
                  _FamilyTextField(
                    familyController: _familyRequirementsController,
                    familyHint: 'Add activity requirements...',
                    familyMaxLines: 2,
                  ),
                  const SizedBox(height: 16),
                  const _FamilyFieldLabel(familyLabel: 'Interest Tags'),
                  _FamilyTextField(
                    familyController: _familyTagsController,
                    familyHint: 'Care, Health, Memory',
                  ),
                  const SizedBox(height: 30),
                  _FamilyPrimaryButton(
                    familyLabel: 'Create Family Activity',
                    familyOnPressed: familyCreateActivity,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
      bottomNavigationBar: BottomNav(
                  selectedIndex: 2,
                  onSelected: (i) => Navigator.of(context).pushAndRemoveUntil(
                    MaterialPageRoute(builder: (_) => HomePage(initialTabIndex: i)),
                    (route) => false,
                  ),
                ),
    );
  }
}

class _FamilyHeader extends StatelessWidget {
  // 创建 Family 顶部栏。
  const _FamilyHeader({
    required this.familyTitle,
    this.familyShowBack = false,
    this.familyActionIcon,
    this.familyOnAction,
  });

  final String familyTitle;
  final bool familyShowBack;
  final IconData? familyActionIcon;
  final VoidCallback? familyOnAction;

  // 构建 Family 顶部栏。
  @override
  Widget build(BuildContext context) {
    return Container(
      width: double.infinity,
      padding: EdgeInsets.only(top: MediaQuery.of(context).padding.top),
      color: Colors.white,
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          SizedBox(
            width: double.infinity,
            height: 58,
            child: Stack(
              alignment: Alignment.center,
              children: [
                Positioned(
                  left: 8,
                  child: familyShowBack
                      ? IconButton(
                          tooltip: 'Back',
                          onPressed: () => Navigator.maybePop(context),
                          icon: const Icon(Icons.arrow_back_ios_new, size: 20),
                        )
                      : const Icon(Icons.diamond_outlined, size: 16),
                ),
                Text(
                  familyTitle,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 24,
                    fontWeight: FontWeight.w800,
                    color: AppTheme.ink,
                  ),
                ),
                if (familyActionIcon != null && familyOnAction != null)
                  Positioned(
                    right: 14,
                    child: InkWell(
                      onTap: familyOnAction,
                      customBorder: const CircleBorder(),
                      child: Container(
                        width: 42,
                        height: 42,
                        decoration: BoxDecoration(
                          shape: BoxShape.circle,
                          border: Border.all(color: AppTheme.ink, width: 2),
                        ),
                        child: Icon(familyActionIcon, size: 28),
                      ),
                    ),
                  ),
              ],
            ),
          ),
          const Divider(height: 1, thickness: 1, color: Color(0xFFD5D5D5)),
        ],
      ),
    );
  }
}

class _FamilyOverviewCard extends StatelessWidget {
  // 创建 Family 总览卡片。
  const _FamilyOverviewCard({
    required this.familyCode,
    required this.familyTitle,
    required this.familySubtitle,
    required this.familyOnTap,
  });

  final String familyCode;
  final String familyTitle;
  final String familySubtitle;
  final VoidCallback familyOnTap;

  // 构建 Family 总览卡片。
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: familyOnTap,
      borderRadius: BorderRadius.circular(14),
      child: Container(
        constraints: const BoxConstraints(minHeight: 104),
        padding: const EdgeInsets.fromLTRB(18, 18, 12, 18),
        decoration: BoxDecoration(
          border: Border.all(color: AppTheme.border),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Row(
          children: [
            _FamilyCircleBadge(familyLabel: familyCode, familySize: 42),
            const SizedBox(width: 18),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    familyTitle,
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.w800,
                      color: AppTheme.ink,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    familySubtitle,
                    style: const TextStyle(
                      fontSize: 12,
                      height: 1.35,
                      color: AppTheme.muted,
                    ),
                  ),
                ],
              ),
            ),
            const Icon(Icons.chevron_right, size: 28),
          ],
        ),
      ),
    );
  }
}

class _FamilyInfoCard extends StatelessWidget {
  // 创建 Family 信息卡片。
  const _FamilyInfoCard({
    required this.familyCode,
    required this.familyTitle,
    required this.familySubtitle,
    this.familyActionLabel,
    this.familyOnAction,
  });

  final String familyCode;
  final String familyTitle;
  final String familySubtitle;
  final String? familyActionLabel;
  final VoidCallback? familyOnAction;

  // 构建 Family 信息卡片。
  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: const BoxConstraints(minHeight: 82),
      padding: const EdgeInsets.fromLTRB(14, 14, 14, 14),
      decoration: BoxDecoration(
        border: Border.all(color: AppTheme.border),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          _FamilyCircleBadge(familyLabel: familyCode, familySize: 44),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  familyTitle,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w800,
                    color: AppTheme.ink,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  familySubtitle,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 12, color: AppTheme.muted),
                ),
              ],
            ),
          ),
          if (familyActionLabel != null && familyOnAction != null) ...[
            const SizedBox(width: 8),
            OutlinedButton(
              onPressed: familyOnAction,
              style: OutlinedButton.styleFrom(
                foregroundColor: AppTheme.ink,
                side: const BorderSide(color: AppTheme.border),
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(14),
                ),
                padding: const EdgeInsets.symmetric(horizontal: 12),
                minimumSize: const Size(56, 34),
              ),
              child: Text(familyActionLabel!),
            ),
          ],
        ],
      ),
    );
  }
}

class _FamilyMemberStatusCard extends StatelessWidget {
  // 创建成员状态卡片。
  const _FamilyMemberStatusCard({required this.familyMember});

  final FamilyMember familyMember;

  // 构建成员状态卡片。
  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: const BoxConstraints(minHeight: 90),
      padding: const EdgeInsets.fromLTRB(8, 14, 14, 14),
      decoration: BoxDecoration(
        border: Border.all(color: AppTheme.border),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          Stack(
            clipBehavior: Clip.none,
            children: [
              _FamilyCircleBadge(
                familyLabel: familyMember.familyInitial,
                familySize: 50,
                familyMutedBorder: true,
              ),
              Positioned(
                right: 0,
                bottom: 2,
                child: _FamilyDot(
                  familyColor: _familyStatusColor(
                    familyMember.familyStatusTone,
                  ),
                ),
              ),
            ],
          ),
          const SizedBox(width: 18),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  '${familyMember.familyName} (${familyMember.familyRole})',
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w800,
                    color: AppTheme.ink,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  familyMember.familyStatusText,
                  style: const TextStyle(fontSize: 12, color: AppTheme.muted),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _FamilyTaskCard extends StatelessWidget {
  // 创建打卡任务卡片。
  const _FamilyTaskCard({required this.familyTask});

  final FamilyCheckInTask familyTask;

  // 构建打卡任务卡片。
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        border: Border.all(color: AppTheme.border),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const _FamilyCircleBadge(familyLabel: 'T', familySize: 42),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  familyTask.familyTitle,
                  style: const TextStyle(
                    fontWeight: FontWeight.w800,
                    color: AppTheme.ink,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  '${familyTask.familyMemberSummary} - ${familyTask.familyType.familyLabel}',
                  style: const TextStyle(fontSize: 12, color: AppTheme.muted),
                ),
                const SizedBox(height: 2),
                Text(
                  familyTask.familyRepeat,
                  style: const TextStyle(fontSize: 12, color: AppTheme.muted),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _FamilyHealthRecordCard extends StatelessWidget {
  // 创建健康记录卡片。
  const _FamilyHealthRecordCard({
    required this.familyRecord,
    required this.familyOnTap,
  });

  final FamilyHealthRecord familyRecord;
  final VoidCallback familyOnTap;

  // 构建健康记录卡片。
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: familyOnTap,
      borderRadius: BorderRadius.circular(12),
      child: Container(
        constraints: const BoxConstraints(minHeight: 86),
        padding: const EdgeInsets.fromLTRB(14, 14, 14, 14),
        decoration: BoxDecoration(
          border: Border.all(color: AppTheme.border),
          borderRadius: BorderRadius.circular(12),
        ),
        child: Row(
          children: [
            const _FamilyCircleBadge(familyLabel: '+', familySize: 44),
            const SizedBox(width: 14),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Text(
                    familyRecord.familyTitle,
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w800,
                      color: AppTheme.ink,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    familyRecord.familyNote,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                    style: const TextStyle(fontSize: 12, color: AppTheme.muted),
                  ),
                  if (familyRecord.familyPhotoTitle.isNotEmpty) ...[
                    const SizedBox(height: 2),
                    Text(
                      familyRecord.familyPhotoTitle,
                      maxLines: 1,
                      overflow: TextOverflow.ellipsis,
                      style: const TextStyle(
                        fontSize: 11,
                        color: AppTheme.muted,
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class _FamilyActivityCard extends StatelessWidget {
  // 创建家庭活动卡片。
  const _FamilyActivityCard({
    required this.familyActivity,
    required this.familyActionLabel,
    required this.familyOnTap,
  });

  final FamilyActivity familyActivity;
  final String familyActionLabel;
  final VoidCallback familyOnTap;

  // 构建家庭活动卡片。
  @override
  Widget build(BuildContext context) {
    return Container(
      constraints: const BoxConstraints(minHeight: 90),
      padding: const EdgeInsets.fromLTRB(14, 14, 14, 14),
      decoration: BoxDecoration(
        border: Border.all(color: AppTheme.border),
        borderRadius: BorderRadius.circular(12),
      ),
      child: Row(
        children: [
          const _FamilyCircleBadge(familyLabel: 'F', familySize: 44),
          const SizedBox(width: 14),
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  familyActivity.familyTitle,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.w800,
                    color: AppTheme.ink,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  familyActivity.familyIsRecent
                      ? '${familyActivity.familyDate} - ${familyActivity.familyDuration}'
                      : '${familyActivity.familyParticipantSummary} - ${familyActivity.familyDuration}',
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 12, color: AppTheme.muted),
                ),
                const SizedBox(height: 2),
                Text(
                  familyActivity.familyIsRecent
                      ? 'Goal: ${familyActivity.familyGoal}'
                      : familyActivity.familyGoal,
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(fontSize: 12, color: AppTheme.muted),
                ),
              ],
            ),
          ),
          const SizedBox(width: 8),
          OutlinedButton(
            onPressed: familyOnTap,
            style: OutlinedButton.styleFrom(
              foregroundColor: AppTheme.ink,
              side: const BorderSide(color: AppTheme.border),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(14),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 12),
              minimumSize: const Size(56, 34),
            ),
            child: Text(familyActionLabel),
          ),
        ],
      ),
    );
  }
}

class _FamilyHealthRecordDialog extends StatefulWidget {
  // 创建健康记录弹窗。
  const _FamilyHealthRecordDialog();

  // 创建弹窗状态。
  @override
  State<_FamilyHealthRecordDialog> createState() =>
      _FamilyHealthRecordDialogState();
}

class _FamilyHealthRecordDialogState extends State<_FamilyHealthRecordDialog> {
  final TextEditingController _familyTitleController = TextEditingController(
    text: 'Health Record Log',
  );
  final TextEditingController _familyNoteController = TextEditingController();
  final TextEditingController _familyPhotoController = TextEditingController();

  // 释放弹窗输入框控制器。
  @override
  void dispose() {
    _familyTitleController.dispose();
    _familyNoteController.dispose();
    _familyPhotoController.dispose();
    super.dispose();
  }

  // 保存健康记录。
  void familySaveRecord() {
    final familyRecord = FamilyHealthRecord(
      familyTitle: _familyTextOrDefault(
        _familyTitleController.text,
        'Health Record Log',
      ),
      familyNote: _familyTextOrDefault(
        _familyNoteController.text,
        'Family admins added a new health note.',
      ),
      familyPhotoTitle: _familyTextOrDefault(
        _familyPhotoController.text,
        'Memory photo note',
      ),
      familyCreatedAt: DateTime.now(),
    );
    FamilyDataStore.familyAddHealthRecord(familyRecord);
    Navigator.of(context).pop();
  }

  // 构建健康记录弹窗。
  @override
  Widget build(BuildContext context) {
    return AlertDialog(
      backgroundColor: Colors.white,
      title: const Text('Add Health Note'),
      content: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            _FamilyTextField(
              familyController: _familyTitleController,
              familyHint: 'Record title',
            ),
            const SizedBox(height: 12),
            _FamilyTextField(
              familyController: _familyNoteController,
              familyHint: 'Health note',
              familyMaxLines: 3,
            ),
            const SizedBox(height: 12),
            _FamilyTextField(
              familyController: _familyPhotoController,
              familyHint: 'Memory photo title or description',
            ),
          ],
        ),
      ),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(context).pop(),
          child: const Text('Cancel'),
        ),
        FilledButton(
          onPressed: familySaveRecord,
          style: FilledButton.styleFrom(backgroundColor: AppTheme.ink),
          child: const Text('Save'),
        ),
      ],
    );
  }
}

class _FamilyCircleBadge extends StatelessWidget {
  // 创建圆形标记。
  const _FamilyCircleBadge({
    required this.familyLabel,
    required this.familySize,
    this.familyMutedBorder = false,
  });

  final String familyLabel;
  final double familySize;
  final bool familyMutedBorder;

  // 构建圆形标记。
  @override
  Widget build(BuildContext context) {
    return Container(
      width: familySize,
      height: familySize,
      alignment: Alignment.center,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        border: Border.all(
          color: familyMutedBorder ? const Color(0xFFC4C8D0) : AppTheme.ink,
          width: familyMutedBorder ? 2 : 1.4,
        ),
      ),
      child: Text(
        familyLabel,
        textAlign: TextAlign.center,
        style: TextStyle(
          color: familyMutedBorder ? AppTheme.muted : AppTheme.ink,
          fontSize: familyLabel.length > 2 ? 10 : 13,
          fontWeight: FontWeight.w700,
        ),
      ),
    );
  }
}

class _FamilyDot extends StatelessWidget {
  // 创建状态小圆点。
  const _FamilyDot({required this.familyColor});

  final Color familyColor;

  // 构建状态小圆点。
  @override
  Widget build(BuildContext context) {
    return Container(
      width: 10,
      height: 10,
      decoration: BoxDecoration(
        color: familyColor,
        shape: BoxShape.circle,
        border: Border.all(color: Colors.white, width: 1.5),
      ),
    );
  }
}

class _FamilySectionTitle extends StatelessWidget {
  // 创建区块标题。
  const _FamilySectionTitle({required this.familyTitle});

  final String familyTitle;

  // 构建区块标题。
  @override
  Widget build(BuildContext context) {
    return Text(
      familyTitle,
      style: const TextStyle(
        fontSize: 22,
        fontWeight: FontWeight.w800,
        color: AppTheme.ink,
      ),
    );
  }
}

class _FamilyFieldLabel extends StatelessWidget {
  // 创建表单标签。
  const _FamilyFieldLabel({required this.familyLabel});

  final String familyLabel;

  // 构建表单标签。
  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 8),
      child: Text(
        familyLabel,
        style: const TextStyle(
          fontWeight: FontWeight.w800,
          color: AppTheme.ink,
        ),
      ),
    );
  }
}

class _FamilyTextField extends StatelessWidget {
  // 创建 Family 输入框。
  const _FamilyTextField({
    required this.familyController,
    required this.familyHint,
    this.familyMaxLines = 1,
  });

  final TextEditingController familyController;
  final String familyHint;
  final int familyMaxLines;

  // 构建 Family 输入框。
  @override
  Widget build(BuildContext context) {
    return TextField(
      controller: familyController,
      maxLines: familyMaxLines,
      decoration: InputDecoration(
        hintText: familyHint,
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 12,
          vertical: 14,
        ),
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(7)),
      ),
    );
  }
}

class _FamilyCheckboxRow extends StatelessWidget {
  // 创建成员复选行。
  const _FamilyCheckboxRow({
    required this.familyLabel,
    required this.familySelected,
    required this.familyOnTap,
  });

  final String familyLabel;
  final bool familySelected;
  final VoidCallback familyOnTap;

  // 构建成员复选行。
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: familyOnTap,
      child: SizedBox(
        height: 48,
        child: Row(
          children: [
            Container(
              width: 20,
              height: 20,
              alignment: Alignment.center,
              decoration: BoxDecoration(
                border: Border.all(color: AppTheme.ink, width: 1.6),
              ),
              child: familySelected
                  ? const Icon(Icons.check, size: 15, color: AppTheme.ink)
                  : null,
            ),
            const SizedBox(width: 16),
            Text(familyLabel, style: const TextStyle(fontSize: 15)),
          ],
        ),
      ),
    );
  }
}

class _FamilyRadioCard extends StatelessWidget {
  // 创建打卡类型单选卡。
  const _FamilyRadioCard({
    required this.familyLabel,
    required this.familySelected,
    required this.familyOnTap,
  });

  final String familyLabel;
  final bool familySelected;
  final VoidCallback familyOnTap;

  // 构建打卡类型单选卡。
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: familyOnTap,
      borderRadius: BorderRadius.circular(8),
      child: Container(
        height: 44,
        padding: const EdgeInsets.symmetric(horizontal: 16),
        decoration: BoxDecoration(
          border: Border.all(color: AppTheme.border),
          borderRadius: BorderRadius.circular(8),
        ),
        child: Row(
          children: [
            Container(
              width: 20,
              height: 20,
              decoration: BoxDecoration(
                shape: BoxShape.circle,
                border: Border.all(color: AppTheme.ink, width: 1.5),
              ),
              child: familySelected
                  ? Center(
                      child: Container(
                        width: 10,
                        height: 10,
                        decoration: const BoxDecoration(
                          shape: BoxShape.circle,
                          color: AppTheme.ink,
                        ),
                      ),
                    )
                  : null,
            ),
            const SizedBox(width: 14),
            Text(familyLabel),
          ],
        ),
      ),
    );
  }
}

class _FamilyPrimaryButton extends StatelessWidget {
  // 创建 Family 主按钮。
  const _FamilyPrimaryButton({
    required this.familyLabel,
    required this.familyOnPressed,
  });

  final String familyLabel;
  final VoidCallback familyOnPressed;

  // 构建 Family 主按钮。
  @override
  Widget build(BuildContext context) {
    return SizedBox(
      width: double.infinity,
      height: 50,
      child: FilledButton(
        onPressed: familyOnPressed,
        style: FilledButton.styleFrom(
          backgroundColor: AppTheme.ink,
          foregroundColor: Colors.white,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(8)),
        ),
        child: Text(
          familyLabel,
          style: const TextStyle(fontWeight: FontWeight.w800),
        ),
      ),
    );
  }
}

class _FamilySelectableTag extends StatelessWidget {
  // 创建可选标签。
  const _FamilySelectableTag({
    required this.familyLabel,
    required this.familySelected,
    required this.familyOnTap,
  });

  final String familyLabel;
  final bool familySelected;
  final VoidCallback familyOnTap;

  // 构建可选标签。
  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: familyOnTap,
      borderRadius: BorderRadius.circular(14),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
        decoration: BoxDecoration(
          color: familySelected ? const Color(0xFFFFF4CF) : Colors.white,
          border: Border.all(
            color: familySelected ? const Color(0xFFD3A51C) : AppTheme.border,
          ),
          borderRadius: BorderRadius.circular(14),
        ),
        child: Text(
          familyLabel,
          style: const TextStyle(fontSize: 12, color: AppTheme.ink),
        ),
      ),
    );
  }
}

class _FamilyDetailRow extends StatelessWidget {
  // 创建详情行。
  const _FamilyDetailRow({
    required this.familyLabel,
    required this.familyValue,
  });

  final String familyLabel;
  final String familyValue;

  // 构建详情行。
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 12),
      decoration: const BoxDecoration(
        border: Border(bottom: BorderSide(color: Color(0xFFE8E8E8))),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            familyLabel,
            style: const TextStyle(
              fontSize: 12,
              fontWeight: FontWeight.w800,
              color: AppTheme.muted,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            familyValue,
            style: const TextStyle(fontSize: 15, color: AppTheme.ink),
          ),
        ],
      ),
    );
  }
}

class _FamilyTag extends StatelessWidget {
  // 创建普通标签。
  const _FamilyTag({required this.familyLabel});

  final String familyLabel;

  // 构建普通标签。
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        border: Border.all(color: AppTheme.border),
        borderRadius: BorderRadius.circular(14),
      ),
      child: Text(
        familyLabel,
        style: const TextStyle(fontSize: 12, color: AppTheme.ink),
      ),
    );
  }
}

// 根据成员状态返回颜色。
Color _familyStatusColor(FamilyStatusTone familyTone) {
  return switch (familyTone) {
    FamilyStatusTone.safe => Colors.green,
    FamilyStatusTone.waiting => const Color(0xFFC4C8D0),
    FamilyStatusTone.active => Colors.blueAccent,
  };
}

// 返回输入文本或默认值。
String _familyTextOrDefault(String familyValue, String familyDefault) {
  final familyTrimmed = familyValue.trim();
  return familyTrimmed.isEmpty ? familyDefault : familyTrimmed;
}

// 显示 Family 提示消息。
void _familyShowSnack(BuildContext context, String familyMessage) {
  ScaffoldMessenger.of(
    context,
  ).showSnackBar(SnackBar(content: Text(familyMessage)));
}
