import 'package:flutter_test/flutter_test.dart';
import 'package:global_village_app/main.dart';

void main() {
  testWidgets('Login page is shown at startup', (tester) async {
    await tester.pumpWidget(const GlobalVillageApp());

    expect(find.text('Global Village'), findsOneWidget);
    expect(find.text('Login'), findsAtLeastNWidgets(1));
    expect(find.text('No account? Register'), findsOneWidget);
  });
}
